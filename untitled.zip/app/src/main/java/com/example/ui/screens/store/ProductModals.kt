package com.example.ui.screens.store

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.entity.DurationPlanEntity
import com.example.data.local.entity.PaymentMethodEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.repository.CheckoutResult
import com.example.domain.model.AppCurrency
import com.example.domain.model.AppLanguage
import com.example.domain.model.CurrencyFormatter
import com.example.domain.model.LocalizationEngine
import com.example.ui.components.CyberBadge
import com.example.ui.components.CyberButton
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberOutlinedButton
import com.example.ui.components.CyberTextField
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCardBg
import com.example.ui.theme.CyberCanvas
import com.example.ui.theme.CyberNeonCyan
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberNeonPink
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun ProductDetailDialog(
    product: ProductEntity,
    durationPlans: List<DurationPlanEntity>,
    selectedPlan: DurationPlanEntity?,
    currency: AppCurrency,
    language: AppLanguage,
    onPlanSelect: (DurationPlanEntity) -> Unit,
    onProceedToCheckout: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CyberCard(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 20.dp),
            borderColor = CyberNeonCyan
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header & Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (language == AppLanguage.BANGLA) product.titleBn else product.title,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                            color = CyberTextPrimary
                        )
                        Text(
                            text = "${product.platform} • ${product.category}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberNeonCyan
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = CyberTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Full Description Box
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .border(BorderStroke(1.dp, CyberBorder), RoundedCornerShape(10.dp)),
                    color = CyberSurface
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "ENGINE SPECIFICATION",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            ),
                            color = CyberTextMuted
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = product.fullDesc,
                            style = MaterialTheme.typography.bodyMedium,
                            color = CyberTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Duration Plan Selector
                Text(
                    text = LocalizationEngine.get("select_duration", language),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = CyberTextPrimary
                )

                Spacer(modifier = Modifier.height(10.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    durationPlans.forEach { plan ->
                        val isSelected = selectedPlan?.id == plan.id
                        val finalPriceUsd = plan.calculateFinalPrice(product.basePriceUsd)

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .border(
                                    BorderStroke(
                                        1.dp,
                                        if (isSelected) CyberNeonCyan else CyberBorder
                                    ),
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { onPlanSelect(plan) }
                                .testTag("plan_item_${plan.id}"),
                            color = if (isSelected) CyberNeonCyan.copy(alpha = 0.12f) else CyberSurface
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.VpnKey,
                                        contentDescription = null,
                                        tint = if (isSelected) CyberNeonCyan else CyberTextMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = if (language == AppLanguage.BANGLA) plan.durationLabelBn else plan.durationLabel,
                                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                                color = if (isSelected) CyberNeonCyan else CyberTextPrimary
                                            )
                                            if (plan.isPopular) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                CyberBadge(text = "POPULAR", color = CyberAccentOrange)
                                            }
                                        }
                                        if (plan.discountPercent > 0) {
                                            Text(
                                                text = "Save ${plan.discountPercent}% off base rate",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = CyberNeonGreen
                                            )
                                        }
                                    }
                                }

                                Text(
                                    text = CurrencyFormatter.format(finalPriceUsd, currency),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        color = if (isSelected) CyberNeonCyan else CyberTextPrimary
                                    )
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action
                CyberButton(
                    text = LocalizationEngine.get("buy_now", language),
                    onClick = onProceedToCheckout,
                    enabled = selectedPlan != null,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_proceed_checkout"
                )
            }
        }
    }
}

@Composable
fun CheckoutDialog(
    product: ProductEntity,
    plan: DurationPlanEntity,
    paymentMethods: List<PaymentMethodEntity>,
    selectedMethod: PaymentMethodEntity?,
    checkoutResult: CheckoutResult?,
    isCheckingOut: Boolean,
    walletBalance: Double,
    currency: AppCurrency,
    language: AppLanguage,
    onSelectPaymentMethod: (PaymentMethodEntity) -> Unit,
    onConfirmPayment: (String?) -> Unit,
    onDismiss: () -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    var txnIdInput by remember { mutableStateOf("") }
    var copiedKey by remember { mutableStateOf(false) }

    val finalPriceUsd = plan.calculateFinalPrice(product.basePriceUsd)
    val convertedPrice = CurrencyFormatter.format(finalPriceUsd, currency)

    Dialog(
        onDismissRequest = {
            if (!isCheckingOut) onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CyberCard(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 20.dp),
            borderColor = if (checkoutResult is CheckoutResult.Success) CyberNeonGreen else CyberNeonCyan
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "SECURE VAULT CHECKOUT",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            ),
                            color = CyberNeonCyan
                        )
                        Text(
                            text = "End-to-End Cryptographic License Delivery",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberTextMuted
                        )
                    }

                    if (!isCheckingOut && checkoutResult !is CheckoutResult.Success) {
                        IconButton(onClick = onDismiss) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = CyberTextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // SUCCESS STATE: Instant Key Reveal
                if (checkoutResult is CheckoutResult.Success) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = "Success",
                            tint = CyberNeonGreen,
                            modifier = Modifier.size(54.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "ORDER COMPLETED & KEY DELIVERED",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            ),
                            color = CyberNeonGreen
                        )

                        Text(
                            text = "Order #${checkoutResult.order.orderNumber}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CyberTextMuted
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Key Box
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .border(BorderStroke(1.dp, CyberNeonGreen), RoundedCornerShape(10.dp)),
                            color = CyberCanvas
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "YOUR PLAIN LICENSE KEY:",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    ),
                                    color = CyberTextMuted
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = checkoutResult.assignedKey,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 1.sp
                                    ),
                                    color = CyberNeonCyan
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CyberButton(
                                text = if (copiedKey) "COPIED TO CLIPBOARD" else "COPY LICENSE KEY",
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(checkoutResult.assignedKey))
                                    copiedKey = true
                                },
                                color = CyberNeonGreen,
                                modifier = Modifier.weight(1f),
                                testTag = "btn_copy_delivered_key"
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        CyberOutlinedButton(
                            text = "CLOSE & GO TO ORDERS",
                            onClick = onDismiss,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "btn_close_checkout_success"
                        )
                    }
                    return@Column
                }

                // Order Summary Card
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .border(BorderStroke(1.dp, CyberBorder), RoundedCornerShape(10.dp)),
                    color = CyberSurface
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = product.title, color = CyberTextPrimary, fontWeight = FontWeight.Bold)
                            Text(text = convertedPrice, color = CyberNeonCyan, fontWeight = FontWeight.Black)
                        }
                        Text(text = plan.durationLabel, color = CyberTextMuted, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Payment Method Selector
                Text(
                    text = "SELECT PAYMENT GATEWAY",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = CyberTextPrimary
                )

                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    paymentMethods.forEach { method ->
                        val isSelected = selectedMethod?.code == method.code
                        val isWallet = method.code == "WALLET"

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .border(
                                    BorderStroke(
                                        1.dp,
                                        if (isSelected) CyberNeonCyan else CyberBorder
                                    ),
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { onSelectPaymentMethod(method) }
                                .testTag("payment_method_${method.code.lowercase()}"),
                            color = if (isSelected) CyberNeonCyan.copy(alpha = 0.12f) else CyberSurface
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (isWallet) Icons.Default.AccountBalanceWallet else Icons.Default.QrCode,
                                        contentDescription = null,
                                        tint = if (isSelected) CyberNeonCyan else CyberTextSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = if (language == AppLanguage.BANGLA) method.nameBn else method.name,
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                            color = if (isSelected) CyberNeonCyan else CyberTextPrimary
                                        )
                                        if (isWallet) {
                                            Text(
                                                text = "Current Balance: ${CurrencyFormatter.format(walletBalance, currency)}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (walletBalance >= finalPriceUsd) CyberNeonGreen else CyberNeonPink
                                            )
                                        } else {
                                            Text(
                                                text = method.addressOrNumber,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = CyberTextMuted
                                            )
                                        }
                                    }
                                }

                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Selected",
                                        tint = CyberNeonCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // If non-wallet payment method selected, show instructions & TxnID input
                if (selectedMethod != null && selectedMethod.code != "WALLET") {
                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .border(BorderStroke(1.dp, CyberBorder), RoundedCornerShape(10.dp)),
                        color = CyberCanvas
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "PAYMENT INSTRUCTIONS",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                ),
                                color = CyberAccentOrange
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (language == AppLanguage.BANGLA) selectedMethod.instructionsBn else selectedMethod.instructions,
                                style = MaterialTheme.typography.bodyMedium,
                                color = CyberTextSecondary
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Merchant/Vault Address: ${selectedMethod.addressOrNumber}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = CyberNeonCyan
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    CyberTextField(
                        value = txnIdInput,
                        onValueChange = { txnIdInput = it },
                        label = "Transaction ID / TrxID / Hash",
                        placeholder = "e.g. 9K77J0982 or 0x8849b...",
                        testTag = "txn_id_input"
                    )
                }

                // Error Message if any
                if (checkoutResult is CheckoutResult.InsufficientWalletBalance) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "⚠️ Insufficient wallet balance ($${String.format("%.2f", checkoutResult.currentBalanceUsd)} vs required $${String.format("%.2f", checkoutResult.requiredUsd)}). Please top up or select bKash/Nagad/Crypto.",
                        color = CyberNeonPink,
                        style = MaterialTheme.typography.labelSmall
                    )
                } else if (checkoutResult is CheckoutResult.OutOfStock) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "⚠️ ${checkoutResult.message}",
                        color = CyberNeonPink,
                        style = MaterialTheme.typography.labelSmall
                    )
                } else if (checkoutResult is CheckoutResult.Failed) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "⚠️ Checkout failed: ${checkoutResult.error}",
                        color = CyberNeonPink,
                        style = MaterialTheme.typography.labelSmall
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Pay Button
                val isWallet = selectedMethod?.code == "WALLET"
                val canSubmit = if (isWallet) (walletBalance >= finalPriceUsd) else txnIdInput.trim().isNotEmpty()

                CyberButton(
                    text = if (isWallet) "PAY WITH WALLET (1-CLICK)" else "VERIFY PAYMENT & REVEAL KEY",
                    onClick = {
                        onConfirmPayment(if (isWallet) null else txnIdInput.trim())
                    },
                    enabled = selectedMethod != null && canSubmit,
                    isLoading = isCheckingOut,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_confirm_pay"
                )
            }
        }
    }
}
