package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.data.repository.MarketRepository
import com.example.data.repository.OrderAndVaultRepository
import com.example.data.repository.SupportAndSecurityRepository
import com.example.data.repository.WalletAndUserRepository

class MainViewModelFactory(
    private val marketRepo: MarketRepository,
    private val orderRepo: OrderAndVaultRepository,
    private val walletRepo: WalletAndUserRepository,
    private val supportRepo: SupportAndSecurityRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(marketRepo, orderRepo, walletRepo, supportRepo) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
