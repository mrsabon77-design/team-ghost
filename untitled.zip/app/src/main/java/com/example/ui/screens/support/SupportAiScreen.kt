package com.example.ui.screens.support

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.entity.SupportTicketEntity
import com.example.domain.model.AppLanguage
import com.example.domain.model.LocalizationEngine
import com.example.ui.components.CyberBadge
import com.example.ui.components.CyberButton
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberTextField
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCanvas
import com.example.ui.theme.CyberCardBg
import com.example.ui.theme.CyberNeonCyan
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.viewmodel.ChatMessageUi
import com.example.ui.viewmodel.MainViewModel

@Composable
fun SupportAiScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val chatMessages by viewModel.aiChatMessages.collectAsState()
    val isAiThinking by viewModel.isAiThinking.collectAsState()
    val tickets by viewModel.userTickets.collectAsState()
    val language by viewModel.language.collectAsState()

    var inputQuestion by remember { mutableStateOf("") }
    var showNewTicketDialog by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    LaunchedEffect(chatMessages.size) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    val promptSuggestions = listOf(
        "How to spoof HWID without BIOS brick?",
        "Valorant Vanguard setup guide",
        "Payment verification time for bKash",
        "How to activate Windows 11 OEM key?"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberCanvas)
            .padding(horizontal = 16.dp)
            .padding(bottom = 80.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Header Card
        CyberCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = CyberNeonCyan.copy(alpha = 0.6f)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberNeonCyan.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SmartToy,
                            contentDescription = "AI Agent",
                            tint = CyberNeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "GHOST AI 24/7 SUPPORT",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black),
                                color = CyberTextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            CyberBadge(text = "GEMINI 3.5", color = CyberNeonGreen)
                        }
                        Text(
                            text = "Instant Troubleshooting & Key Help",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberTextMuted
                        )
                    }
                }

                CyberButton(
                    text = "+ TICKET",
                    onClick = { showNewTicketDialog = true },
                    testTag = "btn_open_new_ticket"
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Prompt suggestions carousel
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            promptSuggestions.forEach { prompt ->
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .border(BorderStroke(1.dp, CyberBorder), RoundedCornerShape(16.dp))
                        .clickable { viewModel.sendAiChatMessage(prompt) },
                    color = CyberSurface
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = CyberNeonCyan,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = prompt,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                            color = CyberTextSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Chat Message Stream
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(chatMessages, key = { it.id }) { msg ->
                ChatMessageBubble(msg = msg)
            }

            if (isAiThinking) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(8.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = CyberNeonCyan,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "GHOST AI is generating answer...",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberTextMuted
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Chat Input Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CyberTextField(
                value = inputQuestion,
                onValueChange = { inputQuestion = it },
                label = "Ask GHOST AI Engineer...",
                placeholder = "Type your question...",
                modifier = Modifier.weight(1f),
                testTag = "ai_chat_input"
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (inputQuestion.isNotBlank()) {
                        viewModel.sendAiChatMessage(inputQuestion.trim())
                        inputQuestion = ""
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(CyberNeonCyan)
                    .testTag("btn_send_ai_message")
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Send",
                    tint = CyberCanvas,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }

    // New Support Ticket Dialog
    if (showNewTicketDialog) {
        CreateTicketDialog(
            onDismiss = { showNewTicketDialog = false },
            onSubmit = { subject, category, message ->
                viewModel.createSupportTicket(subject, category, message) {
                    showNewTicketDialog = false
                }
            }
        )
    }
}

@Composable
fun ChatMessageBubble(msg: ChatMessageUi) {
    val isBot = msg.isBot
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isBot) Arrangement.Start else Arrangement.End
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(if (isBot) 0.92f else 0.82f)
                .clip(
                    RoundedCornerShape(
                        topStart = 14.dp,
                        topEnd = 14.dp,
                        bottomStart = if (isBot) 2.dp else 14.dp,
                        bottomEnd = if (isBot) 14.dp else 2.dp
                    )
                )
                .border(
                    BorderStroke(1.dp, if (isBot) CyberNeonCyan.copy(alpha = 0.4f) else CyberBorder),
                    RoundedCornerShape(
                        topStart = 14.dp,
                        topEnd = 14.dp,
                        bottomStart = if (isBot) 2.dp else 14.dp,
                        bottomEnd = if (isBot) 14.dp else 2.dp
                    )
                ),
            color = if (isBot) CyberSurface else CyberCardBg
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = msg.sender,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isBot) CyberNeonCyan else CyberAccentOrange
                        )
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = msg.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = CyberTextPrimary
                )
            }
        }
    }
}

@Composable
fun CreateTicketDialog(
    onDismiss: () -> Unit,
    onSubmit: (subject: String, category: String, message: String) -> Unit
) {
    var subject by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("TECH_SUPPORT") }
    var message by remember { mutableStateOf("") }

    val categories = listOf("TECH_SUPPORT", "KEY_ISSUE", "PAYMENT_STATUS", "REFUND", "GENERAL")

    Dialog(onDismissRequest = onDismiss) {
        CyberCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "OPEN SUPPORT TICKET",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                        color = CyberNeonCyan
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = CyberTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                CyberTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = "Subject",
                    placeholder = "e.g. HWID Spoofer error code 0x88",
                    testTag = "ticket_subject_input"
                )

                Spacer(modifier = Modifier.height(10.dp))

                CyberTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = "Detailed Issue Description",
                    placeholder = "Describe what happened...",
                    singleLine = false,
                    modifier = Modifier.height(110.dp),
                    testTag = "ticket_message_input"
                )

                Spacer(modifier = Modifier.height(16.dp))

                CyberButton(
                    text = "SUBMIT TICKET TO AI AGENT",
                    onClick = {
                        if (subject.isNotBlank() && message.isNotBlank()) {
                            onSubmit(subject.trim(), category, message.trim())
                        }
                    },
                    enabled = subject.isNotBlank() && message.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_submit_ticket"
                )
            }
        }
    }
}
