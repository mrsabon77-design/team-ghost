package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Cyber Luxe Gaming Palette (#060709 Canvas, Translucent Glass Surfaces, Vibrant Glowing Neon Orange)
val CyberCanvas = Color(0xFF060709)
val CyberBackground = Color(0xFF0A0B0E)
val CyberSurface = Color(0xFF0F1117)
val CyberSurfaceElevated = Color(0xFF141720)
val CyberCardBg = Color(0xFF10131B)
val CyberGlassCard = Color(0xD910131B) // 85% opacity dark glass
val CyberGlassHeader = Color(0xEB08090E)
val CyberSurfaceBorder = Color(0xFF1E2330)
val CyberBorder = Color(0xFF222838)
val CyberBorderSubtle = Color(0x1FFFFFFF)
val CyberGlass = Color(0xDD0A0C12)

// Signature Glowing Cyber Accents
val CyberAccentOrange = Color(0xFFFF6B00)
val CyberNeonOrange = Color(0xFFFF7A00)
val CyberGlowOrange = Color(0xFFFF8C1A)
val CyberOrangeSubtle = Color(0x33FF6B00)
val CyberNeonCyan = Color(0xFF00E5FF)
val CyberNeonGreen = Color(0xFF00E676)
val CyberNeonPurple = Color(0xFFB388FF)
val CyberNeonPink = Color(0xFFFF4081)
val CyberWarningRed = Color(0xFFFF1744)

// Text Colors (High contrast, gaming crispness)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xCCFFFFFF) // 80% opacity white
val TextMuted = Color(0x73FFFFFF)     // 45% opacity white
val TextCyan = Color(0xFF00E5FF)
val TextOrange = Color(0xFFFF7A00)

val CyberTextPrimary = TextPrimary
val CyberTextSecondary = TextSecondary
val CyberTextMuted = TextMuted

// Tier Badges
val TierBronze = Color(0xFFCD7F32)
val TierSilver = Color(0xFFE2E8F0)
val TierGold = Color(0xFFFFB300)
val TierVip = Color(0xFFB388FF)
val TierElite = Color(0xFFFF6B00)
