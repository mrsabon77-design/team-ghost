package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.DigitalKeyEntity
import com.example.data.local.entity.DurationPlanEntity
import com.example.data.local.entity.FeatureFlagEntity
import com.example.data.local.entity.NotificationEntity
import com.example.data.local.entity.OrderEntity
import com.example.data.local.entity.PaymentMethodEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SecurityAuditLogEntity
import com.example.data.local.entity.SupportMessageEntity
import com.example.data.local.entity.SupportTicketEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.WalletLedgerEntity
import com.example.data.repository.CheckoutResult
import com.example.data.repository.MarketRepository
import com.example.data.repository.OrderAndVaultRepository
import com.example.data.repository.SupportAndSecurityRepository
import com.example.data.repository.WalletAndUserRepository
import com.example.domain.engine.LedgerResult
import com.example.domain.engine.StockForecast
import com.example.domain.engine.TotpAuthEngine
import com.example.domain.model.AppCurrency
import com.example.domain.model.AppLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppNavTab {
    STORE,
    ORDERS,
    WALLET,
    SUPPORT,
    PROFILE,
    ADMIN
}

enum class AdminSubTab {
    OVERVIEW,
    KEY_VAULT,
    RECONCILIATION,
    USERS,
    SECURITY_LOGS,
    FLAGS,
    API_DOCS
}

data class ChatMessageUi(
    val id: String = UUID.randomUUID().toString(),
    val sender: String,
    val isBot: Boolean,
    val text: String,
    val time: Long = System.currentTimeMillis()
)

class MainViewModel(
    private val marketRepo: MarketRepository,
    private val orderRepo: OrderAndVaultRepository,
    private val walletRepo: WalletAndUserRepository,
    private val supportRepo: SupportAndSecurityRepository
) : ViewModel() {

    // --- Navigation & Preferences ---
    private val _currentTab = MutableStateFlow(AppNavTab.STORE)
    val currentTab: StateFlow<AppNavTab> = _currentTab.asStateFlow()

    private val _adminSubTab = MutableStateFlow(AdminSubTab.OVERVIEW)
    val adminSubTab: StateFlow<AdminSubTab> = _adminSubTab.asStateFlow()

    private val _currency = MutableStateFlow(AppCurrency.USD)
    val currency: StateFlow<AppCurrency> = _currency.asStateFlow()

    private val _language = MutableStateFlow(AppLanguage.ENGLISH)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    // --- Active User (Default: Super Admin mrsabon77@gmail.com) ---
    private val _currentUserId = MutableStateFlow("user_super_admin_sabon")
    val currentUserId: StateFlow<String> = _currentUserId.asStateFlow()

    val currentUser: StateFlow<UserEntity?> = _currentUserId.combine(walletRepo.getAllUsers()) { uid, users ->
        users.find { it.id == uid }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allUsers: StateFlow<List<UserEntity>> = walletRepo.getAllUsers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Store & Catalog ---
    private val _selectedCategory = MutableStateFlow("ALL")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val allProducts: StateFlow<List<ProductEntity>> = combine(
        marketRepo.getAllProducts(),
        _selectedCategory,
        _searchQuery
    ) { products, cat, query ->
        products.filter { prod ->
            val matchCat = if (cat == "ALL") true else prod.category == cat
            val matchQuery = if (query.isBlank()) true else {
                prod.title.contains(query, ignoreCase = true) ||
                        prod.shortDesc.contains(query, ignoreCase = true) ||
                        prod.platform.contains(query, ignoreCase = true)
            }
            matchCat && matchQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val flashSaleProducts: StateFlow<List<ProductEntity>> = marketRepo.getFlashSaleProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Product Detail & Checkout Selection ---
    private val _selectedProduct = MutableStateFlow<ProductEntity?>(null)
    val selectedProduct: StateFlow<ProductEntity?> = _selectedProduct.asStateFlow()

    private val _productDurationPlans = MutableStateFlow<List<DurationPlanEntity>>(emptyList())
    val productDurationPlans: StateFlow<List<DurationPlanEntity>> = _productDurationPlans.asStateFlow()

    private val _selectedDurationPlan = MutableStateFlow<DurationPlanEntity?>(null)
    val selectedDurationPlan: StateFlow<DurationPlanEntity?> = _selectedDurationPlan.asStateFlow()

    // --- Checkout & Payment Flow ---
    val paymentMethods: StateFlow<List<PaymentMethodEntity>> = orderRepo.getActivePaymentMethods()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedPaymentMethod = MutableStateFlow<PaymentMethodEntity?>(null)
    val selectedPaymentMethod: StateFlow<PaymentMethodEntity?> = _selectedPaymentMethod.asStateFlow()

    private val _checkoutState = MutableStateFlow<CheckoutResult?>(null)
    val checkoutState: StateFlow<CheckoutResult?> = _checkoutState.asStateFlow()

    private val _isCheckingOut = MutableStateFlow(false)
    val isCheckingOut: StateFlow<Boolean> = _isCheckingOut.asStateFlow()

    // --- Orders & Key Vault ---
    val userOrders: StateFlow<List<OrderEntity>> = _currentUserId.combine(orderRepo.getAllOrders()) { uid, orders ->
        orders.filter { it.userId == uid }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allOrders: StateFlow<List<OrderEntity>> = orderRepo.getAllOrders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allVaultKeys: StateFlow<List<DigitalKeyEntity>> = orderRepo.getAllKeys()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalAvailableVaultKeys: StateFlow<Int> = orderRepo.getTotalVaultKeysCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalRevenue: StateFlow<Double?> = orderRepo.getTotalRevenue()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // --- Wallet & Ledger ---
    val walletBalance: StateFlow<Double> = _currentUserId.combine(walletRepo.getAllLedgerEntries()) { uid, entries ->
        val credits = entries.filter { it.userId == uid && it.entryType == "CREDIT" }.sumOf { it.amountUsd }
        val debits = entries.filter { it.userId == uid && it.entryType == "DEBIT" }.sumOf { it.amountUsd }
        credits - debits
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val userLedgerEntries: StateFlow<List<WalletLedgerEntity>> = _currentUserId.combine(walletRepo.getAllLedgerEntries()) { uid, entries ->
        entries.filter { it.userId == uid }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLedgerEntries: StateFlow<List<WalletLedgerEntity>> = walletRepo.getAllLedgerEntries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Notifications ---
    val userNotifications: StateFlow<List<NotificationEntity>> = _currentUserId.combine(walletRepo.getAllUsers()) { uid, _ ->
        emptyList<NotificationEntity>()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Support & AI Chat ---
    private val _aiChatMessages = MutableStateFlow<List<ChatMessageUi>>(
        listOf(
            ChatMessageUi(
                sender = "GHOST AI",
                isBot = true,
                text = "Welcome to TEAM GHOST 24/7 Support Core. Ask me about HWID Spoofing, driver installation, game bypass status, or payment verification!"
            )
        )
    )
    val aiChatMessages: StateFlow<List<ChatMessageUi>> = _aiChatMessages.asStateFlow()

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    val userTickets: StateFlow<List<SupportTicketEntity>> = _currentUserId.combine(supportRepo.getAllTickets()) { uid, tickets ->
        tickets.filter { it.userId == uid }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTickets: StateFlow<List<SupportTicketEntity>> = supportRepo.getAllTickets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Security Audit Logs & Feature Flags ---
    val recentAuditLogs: StateFlow<List<SecurityAuditLogEntity>> = supportRepo.getRecentAuditLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val highRiskSecurityAlerts: StateFlow<List<SecurityAuditLogEntity>> = supportRepo.getHighRiskSecurityAlerts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val featureFlags: StateFlow<List<FeatureFlagEntity>> = supportRepo.getFeatureFlags()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Actions ---

    fun setTab(tab: AppNavTab) {
        _currentTab.value = tab
    }

    fun setAdminSubTab(subTab: AdminSubTab) {
        _adminSubTab.value = subTab
    }

    fun setCurrency(cur: AppCurrency) {
        _currency.value = cur
    }

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
    }

    fun setCategory(cat: String) {
        _selectedCategory.value = cat
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectProduct(product: ProductEntity?) {
        _selectedProduct.value = product
        if (product != null) {
            viewModelScope.launch {
                marketRepo.getDurationPlansForProduct(product.id).collect { plans ->
                    _productDurationPlans.value = plans
                    if (plans.isNotEmpty()) {
                        _selectedDurationPlan.value = plans.firstOrNull { it.isPopular } ?: plans.first()
                    }
                }
            }
        } else {
            _productDurationPlans.value = emptyList()
            _selectedDurationPlan.value = null
        }
    }

    fun selectDurationPlan(plan: DurationPlanEntity) {
        _selectedDurationPlan.value = plan
    }

    fun selectPaymentMethod(method: PaymentMethodEntity) {
        _selectedPaymentMethod.value = method
    }

    fun switchUser(userId: String) {
        _currentUserId.value = userId
    }

    fun executeCheckout(txnId: String?) {
        val user = currentUser.value ?: return
        val product = selectedProduct.value ?: return
        val plan = selectedDurationPlan.value ?: return
        val method = selectedPaymentMethod.value ?: return

        _isCheckingOut.value = true
        _checkoutState.value = null

        viewModelScope.launch {
            val basePrice = product.basePriceUsd
            val calculatedPriceUsd = plan.calculateFinalPrice(basePrice)
            val idempotencyKey = "IDEMP-${user.id}-${product.id}-${plan.id}-${System.currentTimeMillis() / 10000}"

            val result = orderRepo.processCheckout(
                userId = user.id,
                userEmail = user.email,
                productId = product.id,
                productTitle = product.title,
                durationId = plan.id,
                durationLabel = plan.durationLabel,
                durationDays = plan.durationDays,
                amountUsd = calculatedPriceUsd,
                currencyCode = currency.value.code,
                localAmount = calculatedPriceUsd * currency.value.exchangeRateToUsd,
                paymentMethodCode = method.code,
                paymentTxnId = txnId,
                idempotencyKey = idempotencyKey
            )

            _checkoutState.value = result
            _isCheckingOut.value = false
        }
    }

    fun clearCheckoutState() {
        _checkoutState.value = null
    }

    fun topUpWallet(amountUsd: Double, methodCode: String, txnId: String, onComplete: (Boolean, String) -> Unit) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val res = walletRepo.topUpWallet(user.id, amountUsd, methodCode, txnId)
            when (res) {
                is LedgerResult.Success -> onComplete(true, "Successfully added $$amountUsd to your wallet!")
                is LedgerResult.Error -> onComplete(false, res.message)
                is LedgerResult.InsufficientFunds -> onComplete(false, "Top up failed.")
            }
        }
    }

    fun redeemVoucher(code: String, onResult: (Boolean, String) -> Unit) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val (success, msg) = walletRepo.redeemVoucher(user.id, code)
            onResult(success, msg)
        }
    }

    fun sendAiChatMessage(userText: String) {
        if (userText.isBlank()) return
        val userMsg = ChatMessageUi(sender = "User", isBot = false, text = userText)
        _aiChatMessages.value = _aiChatMessages.value + userMsg
        _isAiThinking.value = true

        viewModelScope.launch {
            val reply = supportRepo.askInstantAi(userText)
            val botMsg = ChatMessageUi(sender = "GHOST AI", isBot = true, text = reply)
            _aiChatMessages.value = _aiChatMessages.value + botMsg
            _isAiThinking.value = false
        }
    }

    fun createSupportTicket(subject: String, category: String, message: String, onCreated: (String) -> Unit) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val ticketId = supportRepo.createTicket(user.id, user.email, subject, category, message)
            onCreated(ticketId)
        }
    }

    fun toggle2Fa(enabled: Boolean) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            walletRepo.setTwoFactor(user.id, enabled)
        }
    }

    fun updateUserRole(userId: String, newRole: String) {
        viewModelScope.launch {
            walletRepo.updateUserRole(userId, newRole)
        }
    }

    fun addKeysInBulk(productId: String, durationId: String, rawKeysText: String, onComplete: (Int) -> Unit) {
        val keysList = rawKeysText.split("\n", ",").map { it.trim() }.filter { it.isNotBlank() }
        viewModelScope.launch {
            val count = orderRepo.addKeysInBulk(productId, durationId, keysList)
            onComplete(count)
        }
    }

    fun toggleFeatureFlag(key: String, isEnabled: Boolean) {
        viewModelScope.launch {
            supportRepo.toggleFeatureFlag(key, isEnabled)
        }
    }

    fun updateKeyStatus(keyId: String, newStatus: String) {
        viewModelScope.launch {
            orderRepo.updateKeyStatus(keyId, newStatus)
        }
    }
}
