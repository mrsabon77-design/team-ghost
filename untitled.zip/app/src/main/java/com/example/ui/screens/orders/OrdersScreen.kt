package com.example.ui.screens.orders

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.OrderEntity
import com.example.domain.model.AppCurrency
import com.example.domain.model.AppLanguage
import com.example.domain.model.CurrencyFormatter
import com.example.domain.model.LocalizationEngine
import com.example.ui.components.CyberBadge
import com.example.ui.components.CyberButton
import com.example.ui.components.CyberCard
import com.example.ui.components.KeyVaultCard
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCanvas
import com.example.ui.theme.CyberNeonCyan
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OrdersScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val orders by viewModel.userOrders.collectAsState()
    val currency by viewModel.currency.collectAsState()
    val language by viewModel.language.collectAsState()
    val clipboardManager = LocalClipboardManager.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberCanvas)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Header Banner
            CyberCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = CyberNeonCyan.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = LocalizationEngine.get("orders_title", language),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp
                            ),
                            color = CyberTextPrimary
                        )
                        Text(
                            text = "${orders.size} Total Orders Fulfilled",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CyberNeonCyan
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyberCanvas)
                            .border(BorderStroke(1.dp, CyberBorder), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = "Vault",
                            tint = CyberNeonCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }

        if (orders.isEmpty()) {
            item {
                CyberCard(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = "No Orders",
                            tint = CyberTextMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "You have no active license keys yet.",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = CyberTextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Purchase HWID spoofers, gaming passes, or VPN tokens in the Store to receive instant vault keys.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CyberTextMuted,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                        CyberButton(
                            text = "BROWSE PRODUCT CATALOG",
                            onClick = { viewModel.setTab(AppNavTab.STORE) },
                            testTag = "btn_browse_catalog_empty"
                        )
                    }
                }
            }
        } else {
            items(orders, key = { it.id }) { order ->
                if (order.assignedKey != null) {
                    KeyVaultCard(
                        plainKey = order.assignedKey,
                        productTitle = order.productTitle,
                        durationLabel = order.durationLabel,
                        orderNumber = order.orderNumber,
                        expiresAt = order.keyExpiresAt,
                        onCopy = {
                            clipboardManager.setText(AnnotatedString(order.assignedKey))
                        }
                    )
                } else {
                    PendingOrderCard(order = order, currency = currency)
                }
            }
        }
    }
}

@Composable
fun PendingOrderCard(order: OrderEntity, currency: AppCurrency) {
    val dateStr = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(order.createdAt))

    CyberCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = CyberAccentOrange.copy(alpha = 0.5f)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = order.productTitle,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = CyberTextPrimary
                    )
                    Text(
                        text = "Order #${order.orderNumber} • $dateStr",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberTextMuted
                    )
                }
                CyberBadge(text = order.status, color = CyberAccentOrange)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Payment Method: ${order.paymentMethodCode} • Txn: ${order.paymentTxnId ?: "PENDING"}",
                style = MaterialTheme.typography.bodyMedium,
                color = CyberTextSecondary
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Amount: ${CurrencyFormatter.format(order.amountUsd, currency)}",
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Black),
                color = CyberNeonCyan
            )
        }
    }
}
