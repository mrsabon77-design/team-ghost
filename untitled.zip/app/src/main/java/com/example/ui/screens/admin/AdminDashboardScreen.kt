package com.example.ui.screens.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Api
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.entity.DigitalKeyEntity
import com.example.data.local.entity.FeatureFlagEntity
import com.example.data.local.entity.OrderEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SecurityAuditLogEntity
import com.example.data.local.entity.UserEntity
import com.example.domain.model.AppLanguage
import com.example.ui.components.CyberBadge
import com.example.ui.components.CyberButton
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberOutlinedButton
import com.example.ui.components.CyberTextField
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCanvas
import com.example.ui.theme.CyberNeonCyan
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberNeonPink
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.viewmodel.AdminSubTab
import com.example.ui.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminDashboardScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val adminSubTab by viewModel.adminSubTab.collectAsState()
    val totalRevenue by viewModel.totalRevenue.collectAsState()
    val completedOrders by viewModel.allOrders.collectAsState()
    val vaultKeys by viewModel.allVaultKeys.collectAsState()
    val totalAvailableKeys by viewModel.totalAvailableVaultKeys.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState()
    val products by viewModel.allProducts.collectAsState()
    val auditLogs by viewModel.recentAuditLogs.collectAsState()
    val featureFlags by viewModel.featureFlags.collectAsState()
    val language by viewModel.language.collectAsState()

    var showAddKeysDialog by remember { mutableStateOf(false) }

    val isSuperAdmin = currentUser?.role == "SUPER_ADMIN"

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberCanvas)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Top Sub-Tab Navigation Bar
        AdminSubNavBar(
            selectedSubTab = adminSubTab,
            onSelectSubTab = { viewModel.setAdminSubTab(it) }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Sub-Tab Content
        when (adminSubTab) {
            AdminSubTab.OVERVIEW -> {
                AdminOverviewTab(
                    totalRevenueUsd = totalRevenue ?: 0.0,
                    completedOrdersCount = completedOrders.filter { it.status == "COMPLETED" }.size,
                    totalAvailableKeys = totalAvailableKeys,
                    totalUsers = allUsers.size,
                    onOpenKeyVault = { viewModel.setAdminSubTab(AdminSubTab.KEY_VAULT) }
                )
            }
            AdminSubTab.KEY_VAULT -> {
                AdminKeyVaultTab(
                    keys = vaultKeys,
                    products = products,
                    onOpenAddKeys = { showAddKeysDialog = true },
                    onUpdateKeyStatus = { id, status -> viewModel.updateKeyStatus(id, status) }
                )
            }
            AdminSubTab.RECONCILIATION -> {
                AdminReconciliationTab(orders = completedOrders)
            }
            AdminSubTab.USERS -> {
                AdminUsersTab(
                    users = allUsers,
                    onUpdateRole = { uid, role -> viewModel.updateUserRole(uid, role) }
                )
            }
            AdminSubTab.SECURITY_LOGS -> {
                AdminSecurityAuditTab(logs = auditLogs)
            }
            AdminSubTab.FLAGS -> {
                AdminFeatureFlagsTab(
                    flags = featureFlags,
                    onToggleFlag = { key, enabled -> viewModel.toggleFeatureFlag(key, enabled) }
                )
            }
            AdminSubTab.API_DOCS -> {
                AdminApiExplorerTab()
            }
        }
    }

    if (showAddKeysDialog) {
        AddKeysDialog(
            products = products,
            onDismiss = { showAddKeysDialog = false },
            onSubmit = { prodId, durId, rawKeys ->
                viewModel.addKeysInBulk(prodId, durId, rawKeys) {
                    showAddKeysDialog = false
                }
            }
        )
    }
}

@Composable
fun AdminSubNavBar(
    selectedSubTab: AdminSubTab,
    onSelectSubTab: (AdminSubTab) -> Unit
) {
    val tabs = listOf(
        AdminSubTab.OVERVIEW to "OVERVIEW",
        AdminSubTab.KEY_VAULT to "KEY VAULT",
        AdminSubTab.RECONCILIATION to "RECONCILIATION",
        AdminSubTab.USERS to "USER RBAC",
        AdminSubTab.SECURITY_LOGS to "AUDIT LOGS",
        AdminSubTab.FLAGS to "FLAGS",
        AdminSubTab.API_DOCS to "API EXPLORER"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        tabs.forEach { (subTab, label) ->
            val isSelected = selectedSubTab == subTab
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .border(
                        BorderStroke(1.dp, if (isSelected) CyberAccentOrange else CyberBorder),
                        RoundedCornerShape(8.dp)
                    )
                    .clickable { onSelectSubTab(subTab) }
                    .testTag("admin_subtab_${subTab.name.lowercase()}"),
                color = if (isSelected) CyberAccentOrange.copy(alpha = 0.15f) else CyberSurface
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 11.sp
                    ),
                    color = if (isSelected) CyberAccentOrange else CyberTextSecondary,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                )
            }
        }
    }
}

@Composable
fun AdminOverviewTab(
    totalRevenueUsd: Double,
    completedOrdersCount: Int,
    totalAvailableKeys: Int,
    totalUsers: Int,
    onOpenKeyVault: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            CyberCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = CyberAccentOrange.copy(alpha = 0.7f)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "MASTER CONTROL OVERVIEW",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                            color = CyberAccentOrange
                        )
                        CyberBadge(text = "SUPER ADMIN ACTIVE", color = CyberAccentOrange)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Real-time telemetry, double-entry ledger audits, and zero-trust key inventory.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CyberTextSecondary
                    )
                }
            }
        }

        // Metrics Grid (2x2)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "TOTAL REVENUE",
                    value = "$${String.format("%.2f", totalRevenueUsd)}",
                    badge = "+100% LEDGER AUDITED",
                    color = CyberNeonGreen,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "COMPLETED ORDERS",
                    value = "$completedOrdersCount",
                    badge = "INSTANT DELIVERED",
                    color = CyberNeonCyan,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "KEYS IN VAULT",
                    value = "$totalAvailableKeys",
                    badge = "READY FOR DISPATCH",
                    color = CyberAccentOrange,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "ACTIVE USERS",
                    value = "$totalUsers",
                    badge = "RBAC SECURED",
                    color = CyberTextPrimary,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Quick Actions
        item {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "QUICK ADMINISTRATIVE ACTIONS",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = CyberTextPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    CyberButton(
                        text = "MANAGE DIGITAL KEY VAULT",
                        onClick = onOpenKeyVault,
                        color = CyberAccentOrange,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    badge: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, CyberBorder), RoundedCornerShape(12.dp)),
        color = CyberSurface
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                color = CyberTextMuted
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                color = color
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = badge,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                color = color.copy(alpha = 0.8f)
            )
        }
    }
}

@Composable
fun AdminKeyVaultTab(
    keys: List<DigitalKeyEntity>,
    products: List<ProductEntity>,
    onOpenAddKeys: () -> Unit,
    onUpdateKeyStatus: (keyId: String, status: String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "VAULT INVENTORY (${keys.size} KEYS)",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black),
                    color = CyberTextPrimary
                )
                CyberButton(
                    text = "+ BULK INJECT KEYS",
                    onClick = onOpenAddKeys,
                    color = CyberAccentOrange,
                    testTag = "btn_open_bulk_inject"
                )
            }
        }

        items(keys, key = { it.id }) { keyItem ->
            val productTitle = products.find { it.id == keyItem.productId }?.title ?: keyItem.productId
            val isAvailable = keyItem.status == "AVAILABLE"

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(BorderStroke(1.dp, CyberBorder), RoundedCornerShape(8.dp)),
                color = CyberSurface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = productTitle,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = CyberTextPrimary
                        )
                        Text(
                            text = "Key: ${keyItem.plainKey}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = CyberNeonCyan
                        )
                        Text(
                            text = "Status: ${keyItem.status} • Order: ${keyItem.orderId ?: "NONE"}",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = CyberTextMuted
                        )
                    }

                    CyberBadge(
                        text = keyItem.status,
                        color = when (keyItem.status) {
                            "AVAILABLE" -> CyberNeonGreen
                            "ASSIGNED" -> CyberNeonCyan
                            "LOCKED" -> CyberAccentOrange
                            else -> CyberNeonPink
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun AdminReconciliationTab(orders: List<OrderEntity>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Text(
                text = "GLOBAL TRANSACTION RECONCILIATION (${orders.size} ORDERS)",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black),
                color = CyberTextPrimary
            )
        }

        items(orders, key = { it.id }) { order ->
            val dateStr = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(order.createdAt))
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(BorderStroke(1.dp, CyberBorder), RoundedCornerShape(8.dp)),
                color = CyberSurface
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Order #${order.orderNumber}",
                            fontWeight = FontWeight.Bold,
                            color = CyberNeonCyan
                        )
                        CyberBadge(text = order.status, color = CyberNeonGreen)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${order.productTitle} (${order.durationLabel})",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CyberTextPrimary
                    )
                    Text(
                        text = "User: ${order.userEmail} • Method: ${order.paymentMethodCode} • Txn: ${order.paymentTxnId ?: "N/A"}",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        color = CyberTextMuted
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = dateStr, style = MaterialTheme.typography.labelSmall, color = CyberTextMuted)
                        Text(
                            text = "$${String.format("%.2f", order.amountUsd)}",
                            fontWeight = FontWeight.Black,
                            color = CyberTextPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AdminUsersTab(
    users: List<UserEntity>,
    onUpdateRole: (userId: String, newRole: String) -> Unit
) {
    val roles = listOf("SUPER_ADMIN", "ADMIN", "MANAGER", "SUPPORT", "MEMBER")

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Text(
                text = "USER RBAC & PRIVILEGE MANAGEMENT",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black),
                color = CyberTextPrimary
            )
        }

        items(users, key = { it.id }) { user ->
            var expandedRoleMenu by remember { mutableStateOf(false) }

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(BorderStroke(1.dp, CyberBorder), RoundedCornerShape(8.dp)),
                color = CyberSurface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = user.name, fontWeight = FontWeight.Bold, color = CyberTextPrimary)
                        Text(text = user.email, style = MaterialTheme.typography.labelSmall, color = CyberTextMuted)
                        Text(
                            text = "Loyalty: ${user.loyaltyTier} (${user.loyaltyPoints} pts)",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = CyberNeonGreen
                        )
                    }

                    Box {
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .border(BorderStroke(1.dp, CyberAccentOrange), RoundedCornerShape(6.dp))
                                .clickable { expandedRoleMenu = true },
                            color = CyberAccentOrange.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = user.role,
                                color = CyberAccentOrange,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = expandedRoleMenu,
                            onDismissRequest = { expandedRoleMenu = false },
                            modifier = Modifier.background(CyberSurface)
                        ) {
                            roles.forEach { r ->
                                DropdownMenuItem(
                                    text = { Text(r, color = CyberTextPrimary, fontSize = 12.sp) },
                                    onClick = {
                                        onUpdateRole(user.id, r)
                                        expandedRoleMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminSecurityAuditTab(logs: List<SecurityAuditLogEntity>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Text(
                text = "REAL-TIME SECURITY AUDIT & TELEMETRY",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black),
                color = CyberTextPrimary
            )
        }

        items(logs, key = { it.id }) { log ->
            val dateStr = SimpleDateFormat("dd MMM, HH:mm:ss", Locale.getDefault()).format(Date(log.timestamp))

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(
                        BorderStroke(
                            1.dp,
                            if (log.riskScore in listOf("HIGH", "CRITICAL")) CyberNeonPink else CyberBorder
                        ),
                        RoundedCornerShape(8.dp)
                    ),
                color = CyberSurface
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = log.action,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextPrimary,
                            fontSize = 12.sp
                        )
                        CyberBadge(
                            text = log.riskScore,
                            color = when (log.riskScore) {
                                "CRITICAL", "HIGH" -> CyberNeonPink
                                "MEDIUM" -> CyberAccentOrange
                                else -> CyberNeonGreen
                            }
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = log.details, style = MaterialTheme.typography.bodyMedium, color = CyberTextSecondary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$dateStr • IP: ${log.ipAddress} • Category: ${log.category}",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        color = CyberTextMuted
                    )
                }
            }
        }
    }
}

@Composable
fun AdminFeatureFlagsTab(
    flags: List<FeatureFlagEntity>,
    onToggleFlag: (key: String, enabled: Boolean) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Text(
                text = "RUNTIME FEATURE FLAGS & SYSTEM TOGGLES",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black),
                color = CyberTextPrimary
            )
        }

        items(flags, key = { it.key }) { flag ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(BorderStroke(1.dp, CyberBorder), RoundedCornerShape(8.dp)),
                color = CyberSurface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = flag.label, fontWeight = FontWeight.Bold, color = CyberTextPrimary)
                        Text(text = flag.description, style = MaterialTheme.typography.labelSmall, color = CyberTextMuted)
                    }

                    Switch(
                        checked = flag.isEnabled,
                        onCheckedChange = { onToggleFlag(flag.key, it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyberCanvas,
                            checkedTrackColor = CyberNeonCyan
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun AdminApiExplorerTab() {
    val endpoints = listOf(
        Triple("GET", "/api/v6/products", "Fetch all active digital products and duration plan matrices"),
        Triple("POST", "/api/v6/checkout", "Execute atomic checkout & key reservation with idempotency token"),
        Triple("GET", "/api/v6/vault/keys", "Cryptographically query allocated keys for authenticated user"),
        Triple("POST", "/api/v6/wallet/topup", "Process double-entry wallet credit via bKash, Nagad, USDT, BTC"),
        Triple("POST", "/api/v6/webhooks/telegram", "Simulated webhook event for real-time order dispatch notifications"),
        Triple("POST", "/api/v6/ai/support", "Direct inference gateway for 24/7 Gemini Support Bot")
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "REST API ARCHITECTURE & ENDPOINTS",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                        color = CyberNeonCyan
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Enterprise-ready, microservice-decoupled API contracts with Bearer Token auth.",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberTextMuted
                    )
                }
            }
        }

        items(endpoints) { (method, path, desc) ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .border(BorderStroke(1.dp, CyberBorder), RoundedCornerShape(8.dp)),
                color = CyberSurface
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CyberBadge(
                            text = method,
                            color = if (method == "GET") CyberNeonGreen else CyberAccentOrange
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = path,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            ),
                            color = CyberNeonCyan
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = desc, style = MaterialTheme.typography.bodyMedium, color = CyberTextSecondary)
                }
            }
        }
    }
}

@Composable
fun AddKeysDialog(
    products: List<ProductEntity>,
    onDismiss: () -> Unit,
    onSubmit: (productId: String, durationId: String, rawKeys: String) -> Unit
) {
    var selectedProduct by remember { mutableStateOf<ProductEntity?>(products.firstOrNull()) }
    var durationId by remember { mutableStateOf("plan_prod_hwid_spoofer_30d") }
    var keysInput by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        CyberCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "BULK INJECT LICENSE KEYS",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                        color = CyberAccentOrange
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = CyberTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Target Product: ${selectedProduct?.title ?: "Select"}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = CyberTextPrimary
                )

                Spacer(modifier = Modifier.height(10.dp))

                CyberTextField(
                    value = keysInput,
                    onValueChange = { keysInput = it },
                    label = "Paste Raw License Keys (One per line or comma-separated)",
                    placeholder = "TG-PRO-KEY-001\nTG-PRO-KEY-002\nTG-PRO-KEY-003",
                    singleLine = false,
                    modifier = Modifier.height(120.dp),
                    testTag = "bulk_keys_input"
                )

                Spacer(modifier = Modifier.height(16.dp))

                CyberButton(
                    text = "SEAL KEYS INTO VAULT",
                    onClick = {
                        val prod = selectedProduct
                        if (prod != null && keysInput.isNotBlank()) {
                            onSubmit(prod.id, "plan_${prod.id}_30d", keysInput)
                        }
                    },
                    enabled = selectedProduct != null && keysInput.isNotBlank(),
                    color = CyberAccentOrange,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_seal_keys_submit"
                )
            }
        }
    }
}
