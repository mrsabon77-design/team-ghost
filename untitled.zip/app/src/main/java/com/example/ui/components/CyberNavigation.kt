package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.UserEntity
import com.example.domain.model.AppCurrency
import com.example.domain.model.AppLanguage
import com.example.domain.model.LocalizationEngine
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCanvas
import com.example.ui.theme.CyberGlowOrange
import com.example.ui.theme.CyberNeonCyan
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberNeonOrange
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.viewmodel.AppNavTab

@Composable
fun CyberTopBar(
    currentUser: UserEntity?,
    allUsers: List<UserEntity>,
    selectedCurrency: AppCurrency,
    selectedLanguage: AppLanguage,
    onCurrencySelect: (AppCurrency) -> Unit,
    onLanguageSelect: (AppLanguage) -> Unit,
    onUserSelect: (String) -> Unit,
    onAdminClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var currencyMenuExpanded by remember { mutableStateOf(false) }
    var languageMenuExpanded by remember { mutableStateOf(false) }
    var userMenuExpanded by remember { mutableStateOf(false) }

    val isSuperAdmin = currentUser?.role == "SUPER_ADMIN"

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .border(BorderStroke(1.dp, Color(0x1AFFFFFF))),
        color = Color(0xEB06070A)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Dark Cyber Luxe Gaming Logo & Branding
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { onAdminClick() }
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(CyberAccentOrange, Color(0xFFFF3300))
                            )
                        )
                        .shadow(6.dp, RoundedCornerShape(10.dp), spotColor = CyberAccentOrange),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalFireDepartment,
                        contentDescription = "Ghost Flame",
                        tint = Color.Black,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "TEAM",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                letterSpacing = 1.sp
                            ),
                            color = Color.White
                        )
                        Text(
                            text = "GHOST",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                letterSpacing = 1.sp
                            ),
                            color = CyberAccentOrange
                        )

                        if (isSuperAdmin) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .border(BorderStroke(1.dp, CyberAccentOrange.copy(alpha = 0.4f)), RoundedCornerShape(4.dp)),
                                color = CyberAccentOrange.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "ADMIN",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Black
                                    ),
                                    color = CyberAccentOrange,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = "🟢 14ms • RING-0 SECURE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp
                        ),
                        color = CyberNeonGreen
                    )
                }
            }

            // Top Controls (Currency, Language, User Avatar)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Currency Selector Chip
                Box {
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .border(BorderStroke(1.dp, Color(0xFF22293A)), RoundedCornerShape(10.dp))
                            .clickable { currencyMenuExpanded = true }
                            .testTag("currency_selector_chip"),
                        color = Color(0xD9101420)
                    ) {
                        Text(
                            text = "${selectedCurrency.symbol} ${selectedCurrency.code}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp
                            ),
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = currencyMenuExpanded,
                        onDismissRequest = { currencyMenuExpanded = false },
                        modifier = Modifier.background(Color(0xFF0F121C))
                    ) {
                        AppCurrency.values().forEach { cur ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        "${cur.symbol} ${cur.code} (${if (cur == AppCurrency.BDT) "Rate 122.5" else "1:1"})",
                                        color = if (cur == selectedCurrency) CyberAccentOrange else Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                onClick = {
                                    onCurrencySelect(cur)
                                    currencyMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                // Language Selector Chip
                Box {
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .border(BorderStroke(1.dp, Color(0xFF22293A)), RoundedCornerShape(10.dp))
                            .clickable { languageMenuExpanded = true }
                            .testTag("language_selector_chip"),
                        color = Color(0xD9101420)
                    ) {
                        Text(
                            text = selectedLanguage.code.uppercase(),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp
                            ),
                            color = Color(0xB3FFFFFF),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = languageMenuExpanded,
                        onDismissRequest = { languageMenuExpanded = false },
                        modifier = Modifier.background(Color(0xFF0F121C))
                    ) {
                        AppLanguage.values().forEach { lang ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        lang.displayName,
                                        color = if (lang == selectedLanguage) CyberAccentOrange else Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                },
                                onClick = {
                                    onLanguageSelect(lang)
                                    languageMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                // Glowing User Avatar with Online Dot
                Box {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF141926))
                            .border(
                                BorderStroke(
                                    1.2.dp,
                                    if (isSuperAdmin) CyberAccentOrange else Color(0xFF293247)
                                ),
                                CircleShape
                            )
                            .clickable { userMenuExpanded = true }
                            .testTag("user_avatar_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isSuperAdmin) Icons.Default.AdminPanelSettings else Icons.Default.Person,
                            contentDescription = "User Avatar",
                            tint = if (isSuperAdmin) CyberAccentOrange else Color.White,
                            modifier = Modifier.size(20.dp)
                        )

                        // Online active green dot
                        Box(
                            modifier = Modifier
                                .size(9.dp)
                                .clip(CircleShape)
                                .background(CyberNeonGreen)
                                .border(BorderStroke(1.5.dp, CyberCanvas), CircleShape)
                                .align(Alignment.TopEnd)
                        )
                    }

                    DropdownMenu(
                        expanded = userMenuExpanded,
                        onDismissRequest = { userMenuExpanded = false },
                        modifier = Modifier.background(Color(0xFF0F121C))
                    ) {
                        allUsers.forEach { user ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = user.name,
                                            fontWeight = FontWeight.Bold,
                                            color = if (user.id == currentUser?.id) CyberAccentOrange else Color.White,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = "${user.email} (${user.role})",
                                            color = CyberTextMuted,
                                            fontSize = 10.sp
                                        )
                                    }
                                },
                                onClick = {
                                    onUserSelect(user.id)
                                    userMenuExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CyberBottomNav(
    currentTab: AppNavTab,
    onTabSelect: (AppNavTab) -> Unit,
    isSuperAdmin: Boolean,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
            .fillMaxWidth()
            .border(BorderStroke(1.dp, Color(0x1FFFFFFF))),
        containerColor = Color(0xF207080D),
        tonalElevation = 6.dp
    ) {
        val items = listOf(
            Triple(AppNavTab.STORE, Icons.Default.SportsEsports, LocalizationEngine.get("nav_store", language)),
            Triple(AppNavTab.ORDERS, Icons.Default.ReceiptLong, LocalizationEngine.get("nav_orders", language)),
            Triple(AppNavTab.WALLET, Icons.Default.AccountBalanceWallet, LocalizationEngine.get("nav_wallet", language)),
            Triple(AppNavTab.SUPPORT, Icons.Default.HeadsetMic, LocalizationEngine.get("nav_support", language)),
            Triple(AppNavTab.PROFILE, Icons.Default.Person, LocalizationEngine.get("nav_profile", language)),
            Triple(AppNavTab.ADMIN, Icons.Default.AdminPanelSettings, LocalizationEngine.get("nav_admin", language))
        )

        items.forEach { (tab, icon, label) ->
            val selected = currentTab == tab
            val isTabAdmin = tab == AppNavTab.ADMIN

            NavigationBarItem(
                selected = selected,
                onClick = { onTabSelect(tab) },
                icon = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (selected) {
                            Box(
                                modifier = Modifier
                                    .width(16.dp)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(CyberAccentOrange)
                                    .shadow(4.dp, RoundedCornerShape(2.dp), spotColor = CyberAccentOrange)
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            modifier = Modifier.size(21.dp),
                            tint = when {
                                selected -> CyberAccentOrange
                                isTabAdmin && isSuperAdmin -> CyberAccentOrange.copy(alpha = 0.7f)
                                else -> Color(0x80FFFFFF)
                            }
                        )
                    }
                },
                label = {
                    Text(
                        text = label.uppercase(),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (selected) FontWeight.Black else FontWeight.Bold,
                            fontSize = 9.sp,
                            letterSpacing = 0.5.sp
                        ),
                        color = when {
                            selected -> CyberAccentOrange
                            else -> Color(0x80FFFFFF)
                        }
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = CyberAccentOrange.copy(alpha = 0.12f)
                ),
                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
            )
        }
    }
}
