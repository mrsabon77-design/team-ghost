package com.example.ui.screens.wallet

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.entity.PaymentMethodEntity
import com.example.data.local.entity.WalletLedgerEntity
import com.example.domain.model.AppCurrency
import com.example.domain.model.AppLanguage
import com.example.domain.model.CurrencyFormatter
import com.example.domain.model.LocalizationEngine
import com.example.ui.components.CyberBadge
import com.example.ui.components.CyberButton
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberGradientCard
import com.example.ui.components.CyberOutlinedButton
import com.example.ui.components.CyberTextField
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCanvas
import com.example.ui.theme.CyberNeonCyan
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberNeonPink
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WalletScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val balance by viewModel.walletBalance.collectAsState()
    val ledgerEntries by viewModel.userLedgerEntries.collectAsState()
    val paymentMethods by viewModel.paymentMethods.collectAsState()
    val currency by viewModel.currency.collectAsState()
    val language by viewModel.language.collectAsState()

    var showTopUpDialog by remember { mutableStateOf(false) }
    var showVoucherDialog by remember { mutableStateOf(false) }
    var actionMessage by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberCanvas)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Sophisticated Dark Portfolio Hero Card
        item {
            WalletBalanceHeroCard(
                balanceUsd = balance,
                currency = currency,
                language = language,
                onTopUpClick = { showTopUpDialog = true },
                onVoucherClick = { showVoucherDialog = true }
            )
        }

        if (actionMessage != null) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .border(BorderStroke(1.dp, CyberNeonGreen.copy(alpha = 0.3f)), RoundedCornerShape(12.dp)),
                    color = CyberNeonGreen.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = actionMessage ?: "",
                        color = CyberNeonGreen,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        }

        // Live Operations 2x2 Grid (from Sophisticated Dark Design)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "OPERATIONS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.5.sp
                        ),
                        color = Color(0x66FFFFFF)
                    )

                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .border(BorderStroke(1.dp, CyberAccentOrange.copy(alpha = 0.2f)), RoundedCornerShape(4.dp)),
                        color = CyberAccentOrange.copy(alpha = 0.05f)
                    ) {
                        Text(
                            text = "LIVE FEED",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            ),
                            color = CyberAccentOrange,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OperationGridTile(
                        icon = Icons.Default.Key,
                        iconColor = Color(0xFF38BDF8),
                        iconBg = Color(0xFF38BDF8).copy(alpha = 0.1f),
                        label = "ACTIVE KEYS",
                        value = "1,284",
                        subtext = "+12.4% vs last mo",
                        subtextColor = CyberNeonGreen,
                        modifier = Modifier.weight(1f)
                    )

                    OperationGridTile(
                        icon = Icons.Default.AccountBalanceWallet,
                        iconColor = CyberAccentOrange,
                        iconBg = CyberAccentOrange.copy(alpha = 0.1f),
                        label = "INVENTORY",
                        value = "94.2%",
                        subtext = "Forecast: Optimized",
                        subtextColor = Color(0x66FFFFFF),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OperationGridTile(
                        icon = Icons.Default.Security,
                        iconColor = CyberNeonGreen,
                        iconBg = CyberNeonGreen.copy(alpha = 0.1f),
                        label = "SECURITY",
                        value = "A+",
                        subtext = "Zero-trust active",
                        subtextColor = Color(0x66FFFFFF),
                        modifier = Modifier.weight(1f)
                    )

                    OperationGridTile(
                        icon = Icons.Default.SmartToy,
                        iconColor = Color(0xFFA855F7),
                        iconBg = Color(0xFFA855F7).copy(alpha = 0.1f),
                        label = "AI CORE",
                        value = "98.7%",
                        subtext = "Success rate",
                        subtextColor = Color(0x66FFFFFF),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Ledger Audit Trail Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Ledger",
                        tint = CyberAccentOrange,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = LocalizationEngine.get("recent_transactions", language),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }
                Text(
                    text = "${ledgerEntries.size} Entries",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextMuted
                )
            }
        }

        // Ledger Items
        if (ledgerEntries.isEmpty()) {
            item {
                CyberCard(modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)) {
                    Text(
                        text = "No ledger transactions recorded yet.",
                        color = CyberTextMuted,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            }
        } else {
            items(ledgerEntries, key = { it.id }) { entry ->
                LedgerItemCard(entry = entry, currency = currency)
            }
        }
    }

    // Top Up Dialog
    if (showTopUpDialog) {
        TopUpDialog(
            paymentMethods = paymentMethods.filter { it.code != "WALLET" },
            currency = currency,
            language = language,
            onDismiss = { showTopUpDialog = false },
            onSubmit = { amount, methodCode, txnId ->
                viewModel.topUpWallet(amount, methodCode, txnId) { success, msg ->
                    actionMessage = msg
                    showTopUpDialog = false
                }
            }
        )
    }

    // Voucher Dialog
    if (showVoucherDialog) {
        VoucherDialog(
            onDismiss = { showVoucherDialog = false },
            onApply = { code ->
                viewModel.redeemVoucher(code) { success, msg ->
                    actionMessage = msg
                    showVoucherDialog = false
                }
            }
        )
    }
}

@Composable
fun OperationGridTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    iconBg: Color,
    label: String,
    value: String,
    subtext: String,
    subtextColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .border(BorderStroke(1.dp, Color(0x14FFFFFF)), RoundedCornerShape(20.dp)),
        color = Color(0xFF111111)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(iconBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = iconColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    ),
                    color = Color(0x66FFFFFF)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Column {
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp
                    ),
                    color = Color.White
                )
                Text(
                    text = subtext,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = subtextColor
                )
            }
        }
    }
}

@Composable
fun WalletBalanceHeroCard(
    balanceUsd: Double,
    currency: AppCurrency,
    language: AppLanguage,
    onTopUpClick: () -> Unit,
    onVoucherClick: () -> Unit
) {
    CyberGradientCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = Color(0xFF222222),
        startColor = Color(0xFF1A1A1A),
        endColor = Color(0xFF0A0A0A),
        shape = RoundedCornerShape(28.dp)
    ) {
        Column(modifier = Modifier.padding(22.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "PORTFOLIO VALUE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            letterSpacing = 1.2.sp
                        ),
                        color = Color(0x80FFFFFF)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "$${String.format("%.2f", balanceUsd)}",
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Medium,
                            fontSize = 32.sp
                        ),
                        color = Color.White
                    )
                    if (currency != AppCurrency.USD) {
                        Text(
                            text = "≈ ${CurrencyFormatter.format(balanceUsd, currency)}",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = CyberAccentOrange
                        )
                    }
                }

                // Verified Badge (from Sophisticated Dark Design)
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .border(BorderStroke(1.dp, CyberAccentOrange.copy(alpha = 0.3f)), RoundedCornerShape(20.dp)),
                    color = CyberAccentOrange.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "VERIFIED",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            letterSpacing = 1.5.sp
                        ),
                        color = CyberAccentOrange,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Action Buttons (Deposit / Top up vs Withdraw / Redeem)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CyberButton(
                    text = "DEPOSIT",
                    onClick = onTopUpClick,
                    color = CyberAccentOrange,
                    textColor = Color(0xFF050505),
                    modifier = Modifier.weight(1f),
                    testTag = "btn_open_topup"
                )

                CyberOutlinedButton(
                    text = "REDEEM",
                    onClick = onVoucherClick,
                    borderColor = Color(0xFF333333),
                    backgroundColor = Color(0xFF222222),
                    textColor = Color.White,
                    modifier = Modifier.weight(1f),
                    testTag = "btn_open_voucher"
                )
            }
        }
    }
}

@Composable
fun LedgerItemCard(entry: WalletLedgerEntity, currency: AppCurrency) {
    val isCredit = entry.entryType == "CREDIT"
    val dateStr = SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.getDefault()).format(Date(entry.timestamp))

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(BorderStroke(1.dp, Color(0xFF1E1E1E)), RoundedCornerShape(14.dp)),
        color = Color(0xFF0E0E0E)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isCredit) CyberNeonGreen.copy(alpha = 0.12f) else CyberNeonPink.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isCredit) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                        contentDescription = entry.entryType,
                        tint = if (isCredit) CyberNeonGreen else CyberNeonPink,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = entry.description,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "$dateStr • Ref: ${entry.referenceId}",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        color = Color(0x66FFFFFF)
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${if (isCredit) "+" else "-"}$${String.format("%.2f", entry.amountUsd)}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        color = if (isCredit) CyberNeonGreen else CyberNeonPink
                    )
                )
                Text(
                    text = "Bal: $${String.format("%.2f", entry.balanceAfterUsd)}",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = Color(0x66FFFFFF)
                )
            }
        }
    }
}

@Composable
fun TopUpDialog(
    paymentMethods: List<PaymentMethodEntity>,
    currency: AppCurrency,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onSubmit: (amountUsd: Double, methodCode: String, txnId: String) -> Unit
) {
    var amountInput by remember { mutableStateOf("25") }
    var selectedMethod by remember { mutableStateOf<PaymentMethodEntity?>(paymentMethods.firstOrNull()) }
    var txnIdInput by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        CyberCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 20.dp),
            borderColor = Color(0xFF2E2E2E)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DEPOSIT TO WALLET",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                        color = CyberAccentOrange
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = CyberTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                CyberTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = "Amount (USD)",
                    placeholder = "e.g. 25, 50, 100",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    testTag = "topup_amount_input"
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "SELECT PAYMENT GATEWAY",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    paymentMethods.forEach { method ->
                        val isSelected = selectedMethod?.code == method.code
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .border(
                                    BorderStroke(1.dp, if (isSelected) CyberAccentOrange else Color(0xFF222222)),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { selectedMethod = method },
                            color = if (isSelected) CyberAccentOrange.copy(alpha = 0.12f) else Color(0xFF141414)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = method.name,
                                    color = if (isSelected) CyberAccentOrange else Color.White,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                }

                if (selectedMethod != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp)),
                        color = Color(0xFF050505)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Merchant Number / Address:",
                                color = Color(0x66FFFFFF),
                                fontSize = 10.sp
                            )
                            Text(
                                text = selectedMethod?.addressOrNumber ?: "",
                                color = CyberAccentOrange,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    CyberTextField(
                        value = txnIdInput,
                        onValueChange = { txnIdInput = it },
                        label = "Transaction ID (TrxID / Hash)",
                        placeholder = "e.g. 9K77J0982",
                        testTag = "topup_txnid_input"
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                val amountVal = amountInput.toDoubleOrNull() ?: 0.0
                CyberButton(
                    text = "CONFIRM DEPOSIT",
                    onClick = {
                        if (amountVal > 0 && selectedMethod != null && txnIdInput.isNotBlank()) {
                            onSubmit(amountVal, selectedMethod!!.code, txnIdInput.trim())
                        }
                    },
                    enabled = amountVal > 0 && selectedMethod != null && txnIdInput.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_submit_topup"
                )
            }
        }
    }
}

@Composable
fun VoucherDialog(
    onDismiss: () -> Unit,
    onApply: (String) -> Unit
) {
    var voucherCode by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        CyberCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 20.dp),
            borderColor = Color(0xFF2E2E2E)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "REDEEM PROMO VOUCHER",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                        color = CyberAccentOrange
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = CyberTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                CyberTextField(
                    value = voucherCode,
                    onValueChange = { voucherCode = it },
                    label = "Voucher Code",
                    placeholder = "GHOST2026, CYBERLUXE, ELITE77",
                    testTag = "voucher_input"
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Try demo codes: GHOST2026 ($10), CYBERLUXE ($25), ELITE77 ($50)",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextMuted
                )

                Spacer(modifier = Modifier.height(16.dp))

                CyberButton(
                    text = "CLAIM WALLET BONUS",
                    onClick = { onApply(voucherCode.trim().uppercase()) },
                    enabled = voucherCode.isNotBlank(),
                    color = CyberAccentOrange,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_claim_voucher"
                )
            }
        }
    }
}
