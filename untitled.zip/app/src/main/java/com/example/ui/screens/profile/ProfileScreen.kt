package com.example.ui.screens.profile

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domain.engine.TotpAuthEngine
import com.example.domain.model.AppLanguage
import com.example.domain.model.LocalizationEngine
import com.example.ui.components.CyberBadge
import com.example.ui.components.CyberButton
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberOutlinedButton
import com.example.ui.components.CyberTextField
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCanvas
import com.example.ui.theme.CyberNeonCyan
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberNeonPink
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.MainViewModel

@Composable
fun ProfileScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState()
    val language by viewModel.language.collectAsState()
    val clipboardManager = LocalClipboardManager.current

    var showTotpDialog by remember { mutableStateOf(false) }
    var showLegalDialog by remember { mutableStateOf(false) }
    var copiedCode by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberCanvas)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // User Identity Card
        item {
            currentUser?.let { user ->
                val isSuperAdmin = user.role == "SUPER_ADMIN"
                CyberCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (isSuperAdmin) CyberAccentOrange else CyberNeonCyan
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(if (isSuperAdmin) CyberAccentOrange.copy(alpha = 0.2f) else CyberNeonCyan.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, if (isSuperAdmin) CyberAccentOrange else CyberNeonCyan), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isSuperAdmin) Icons.Default.AdminPanelSettings else Icons.Default.Person,
                                        contentDescription = "Avatar",
                                        tint = if (isSuperAdmin) CyberAccentOrange else CyberNeonCyan,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column {
                                    Text(
                                        text = user.name,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                                        color = CyberTextPrimary
                                    )
                                    Text(
                                        text = user.email,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyberTextMuted
                                    )
                                }
                            }

                            CyberBadge(
                                text = user.role,
                                color = if (isSuperAdmin) CyberAccentOrange else CyberNeonCyan,
                                textColor = CyberCanvas
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Loyalty & Points Stats Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp)),
                                color = CyberCanvas
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "LOYALTY TIER",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                        color = CyberTextMuted
                                    )
                                    Text(
                                        text = user.loyaltyTier,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black),
                                        color = CyberNeonCyan
                                    )
                                }
                            }

                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp)),
                                color = CyberCanvas
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "REWARD POINTS",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                        color = CyberTextMuted
                                    )
                                    Text(
                                        text = "${user.loyaltyPoints} PTS",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black),
                                        color = CyberNeonGreen
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Referral Program Card
        item {
            currentUser?.let { user ->
                CyberCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = CyberBorder
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Referral",
                                    tint = CyberNeonCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = LocalizationEngine.get("referral_program", language),
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = CyberTextPrimary
                                )
                            }
                            CyberBadge(text = "$2.50 / INVITE", color = CyberNeonGreen)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Share your unique referral code. When a friend completes an order, both receive instant wallet credits.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CyberTextSecondary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .border(BorderStroke(1.dp, CyberBorder), RoundedCornerShape(8.dp)),
                            color = CyberCanvas
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = user.referralCode,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Black
                                    ),
                                    color = CyberNeonCyan
                                )

                                IconButton(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(user.referralCode))
                                        copiedCode = true
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = if (copiedCode) Icons.Default.Check else Icons.Default.ContentCopy,
                                        contentDescription = "Copy Referral",
                                        tint = if (copiedCode) CyberNeonGreen else CyberNeonCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Security & 2FA Card
        item {
            currentUser?.let { user ->
                CyberCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = CyberNeonCyan.copy(alpha = 0.4f)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = "Security",
                                    tint = CyberNeonCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = LocalizationEngine.get("security_center", language),
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = CyberTextPrimary
                                )
                            }

                            Switch(
                                checked = user.twoFactorEnabled,
                                onCheckedChange = { viewModel.toggle2Fa(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = CyberCanvas,
                                    checkedTrackColor = CyberNeonCyan,
                                    uncheckedThumbColor = CyberTextMuted,
                                    uncheckedTrackColor = CyberSurface
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Two-Factor Authentication (TOTP / Google Authenticator) protects your key vault and high-value orders.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CyberTextSecondary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        CyberOutlinedButton(
                            text = "TEST TOTP GENERATOR & SECRET",
                            onClick = { showTotpDialog = true },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "btn_open_totp_dialog"
                        )
                    }
                }
            }
        }

        // Fast User Switcher Card (Super Admin mrsabon77@gmail.com vs Demo User)
        item {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SwitchAccount,
                            contentDescription = "Switch",
                            tint = CyberAccentOrange,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SWITCH DEMO ACCOUNT",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = CyberTextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        allUsers.forEach { user ->
                            val isSelected = currentUser?.id == user.id
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(
                                        BorderStroke(1.dp, if (isSelected) CyberNeonCyan else CyberBorder),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { viewModel.switchUser(user.id) }
                                    .testTag("switch_user_${user.email.substringBefore("@")}"),
                                color = if (isSelected) CyberNeonCyan.copy(alpha = 0.12f) else CyberSurface
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = user.name,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) CyberNeonCyan else CyberTextPrimary
                                        )
                                        Text(
                                            text = "${user.email} • ${user.role}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = CyberTextMuted
                                        )
                                    }
                                    if (isSelected) {
                                        CyberBadge(text = "ACTIVE", color = CyberNeonCyan)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Legal & Compliance Button
        item {
            CyberOutlinedButton(
                text = "LEGAL POLICIES & ZERO-LOG GUARANTEE",
                onClick = { showLegalDialog = true },
                modifier = Modifier.fillMaxWidth(),
                borderColor = CyberBorder,
                textColor = CyberTextSecondary,
                testTag = "btn_open_legal"
            )
        }
    }

    // TOTP Dialog
    if (showTotpDialog) {
        TotpTestDialog(
            secret = currentUser?.twoFactorSecret ?: "GHOST-AUTH-KEY",
            onDismiss = { showTotpDialog = false }
        )
    }

    // Legal Dialog
    if (showLegalDialog) {
        LegalPolicyDialog(onDismiss = { showLegalDialog = false })
    }
}

@Composable
fun TotpTestDialog(secret: String, onDismiss: () -> Unit) {
    var currentCode by remember { mutableStateOf(TotpAuthEngine.generateCurrentCode(secret)) }

    Dialog(onDismissRequest = onDismiss) {
        CyberCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "2FA TOTP AUTHENTICATOR",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                        color = CyberNeonCyan
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = CyberTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "CURRENT 6-DIGIT CODE:",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = CyberTextMuted
                )

                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberCanvas)
                        .border(BorderStroke(1.dp, CyberNeonCyan), RoundedCornerShape(10.dp)),
                    color = CyberCanvas
                ) {
                    Text(
                        text = "${currentCode.take(3)} ${currentCode.takeLast(3)}",
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 4.sp
                        ),
                        color = CyberNeonCyan,
                        modifier = Modifier.padding(16.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Secret Key: $secret\n(Regenerates automatically every 30 seconds)",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextMuted,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )

                Spacer(modifier = Modifier.height(18.dp))

                CyberButton(
                    text = "REFRESH CODE",
                    onClick = { currentCode = TotpAuthEngine.generateCurrentCode(secret) },
                    icon = { Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun LegalPolicyDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        CyberCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TEAM GHOST LEGAL & COMPLIANCE",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                        color = CyberNeonCyan
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = CyberTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "1. ZERO-LOGS GUARANTEE\nAll telemetry, keys, and driver communications are encrypted at rest and in transit. No user activity or IP logs are permanently stored.\n\n" +
                            "2. INSTANT DIGITAL REPLACEMENT\nIf a license key fails verification upon first delivery, our automated system re-provisions an alternative working key or credits your wallet ledger.\n\n" +
                            "3. DOUBLE-ENTRY LEDGER FIDELITY\nEvery wallet deposit and transaction is strictly immutable and mathematically verifiable via our internal ledger accounting engine.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CyberTextSecondary
                )

                Spacer(modifier = Modifier.height(16.dp))

                CyberButton(
                    text = "I UNDERSTAND & AGREE",
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
