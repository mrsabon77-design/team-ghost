package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SophisticatedDarkColorScheme = darkColorScheme(
    primary = CyberAccentOrange,
    onPrimary = Color(0xFF050505),
    primaryContainer = Color(0xFF261305),
    onPrimaryContainer = CyberAccentOrange,
    secondary = CyberNeonCyan,
    onSecondary = Color(0xFF050505),
    secondaryContainer = Color(0xFF072736),
    onSecondaryContainer = CyberNeonCyan,
    tertiary = CyberNeonGreen,
    onTertiary = Color(0xFF050505),
    background = CyberCanvas,
    onBackground = TextPrimary,
    surface = CyberSurface,
    onSurface = TextPrimary,
    surfaceVariant = CyberSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = CyberBorder,
    error = CyberWarningRed,
    onError = Color.White
)

@Composable
fun TEAMGHOSTTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SophisticatedDarkColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    TEAMGHOSTTheme(darkTheme = darkTheme, content = content)
}
