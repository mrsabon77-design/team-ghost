package com.example.ui.screens.store

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.VpnLock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.entity.ProductEntity
import com.example.domain.model.AppCurrency
import com.example.domain.model.AppLanguage
import com.example.domain.model.CurrencyFormatter
import com.example.domain.model.LocalizationEngine
import com.example.ui.components.CyberBadge
import com.example.ui.components.CyberButton
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberGlowingCard
import com.example.ui.components.CyberOutlinedButton
import com.example.ui.components.CyberTextField
import com.example.ui.theme.CyberAccentOrange
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCanvas
import com.example.ui.theme.CyberGlassCard
import com.example.ui.theme.CyberGlowOrange
import com.example.ui.theme.CyberNeonCyan
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberNeonOrange
import com.example.ui.theme.CyberNeonPink
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.MainViewModel

@Composable
fun StoreScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val products by viewModel.allProducts.collectAsState()
    val flashSaleProducts by viewModel.flashSaleProducts.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val currency by viewModel.currency.collectAsState()
    val language by viewModel.language.collectAsState()

    val categories = listOf(
        "ALL" to LocalizationEngine.get("filter_all", language),
        "SECURITY" to LocalizationEngine.get("filter_security", language),
        "GAMING" to LocalizationEngine.get("filter_gaming", language),
        "VPN" to LocalizationEngine.get("filter_vpn", language),
        "SUBSCRIPTIONS" to LocalizationEngine.get("filter_subs", language),
        "DEV_TOOLS" to LocalizationEngine.get("filter_devtools", language),
        "SOFTWARE" to LocalizationEngine.get("filter_software", language)
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberCanvas),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // 1. MASSIVE HERO BANNER (Dark Cyber Luxe character art with glowing orange typography)
        item {
            MassiveGamingHeroBanner(
                language = language,
                onExploreClick = { viewModel.setCategory("ALL") },
                onAiSupportClick = { viewModel.setTab(AppNavTab.SUPPORT) }
            )
        }

        // 2. AI SEARCH ASSISTANT BOX & QUICK SUGGESTIONS
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CyberTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    label = LocalizationEngine.get("search_placeholder", language),
                    placeholder = "Search HWID Spoofer, Vanguard, CoD, 10Gbps VPN...",
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = CyberAccentOrange,
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    trailingIcon = {
                        Surface(
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .clip(RoundedCornerShape(8.dp)),
                            color = CyberAccentOrange.copy(alpha = 0.15f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "AI",
                                    tint = CyberAccentOrange,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "AI SEARCH",
                                    color = CyberAccentOrange,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    },
                    testTag = "store_search_input"
                )

                // Quick AI suggestion chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Ring-0 Spoofer", "Apex Legends", "Call of Duty", "WireGuard VPN", "Rust Bypass").forEach { chip ->
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .border(BorderStroke(1.dp, Color(0xFF22293A)), RoundedCornerShape(12.dp))
                                .clickable { viewModel.setSearchQuery(chip) },
                            color = Color(0x80101420)
                        ) {
                            Text(
                                text = "⚡ $chip",
                                color = Color(0xCCFFFFFF),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }
        }

        // 3. CATEGORY SELECTOR CAROUSEL
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { (catCode, catLabel) ->
                    val isSelected = selectedCategory == catCode
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .border(
                                BorderStroke(
                                    1.2.dp,
                                    if (isSelected) CyberAccentOrange else Color(0xFF202636)
                                ),
                                RoundedCornerShape(14.dp)
                            )
                            .clickable { viewModel.setCategory(catCode) }
                            .testTag("cat_chip_$catCode"),
                        color = if (isSelected) CyberAccentOrange.copy(alpha = 0.2f) else Color(0xD910131C)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(CyberAccentOrange)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Text(
                                text = catLabel.uppercase(),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                    fontSize = 11.5.sp,
                                    letterSpacing = 0.5.sp
                                ),
                                color = if (isSelected) CyberAccentOrange else Color(0xB3FFFFFF)
                            )
                        }
                    }
                }
            }
        }

        // 4. FLASH SALE SECTION (Hot Drops)
        if (flashSaleProducts.isNotEmpty() && searchQuery.isBlank() && selectedCategory == "ALL") {
            item {
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    GamingFlashSaleSection(
                        flashProducts = flashSaleProducts,
                        currency = currency,
                        language = language,
                        onProductClick = { viewModel.selectProduct(it) }
                    )
                }
            }
        }

        // 5. CATALOG HEADER
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.SportsEsports,
                        contentDescription = "Catalog",
                        tint = CyberAccentOrange,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = LocalizationEngine.get("all_products", language).uppercase(),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.8.sp,
                            fontSize = 15.sp
                        ),
                        color = Color.White
                    )
                }
                CyberBadge(
                    text = "${products.size} IN STOCK",
                    color = CyberNeonGreen
                )
            }
        }

        // 6. PRODUCT CARDS GRID / LIST (High-End Gaming Marketplace Style)
        if (products.isEmpty()) {
            item {
                CyberCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 20.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Not Found",
                            tint = CyberTextMuted,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No digital licenses found for '$searchQuery'",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CyberTextMuted
                        )
                    }
                }
            }
        } else {
            items(products, key = { it.id }) { product ->
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    GamingProductCard(
                        product = product,
                        currency = currency,
                        language = language,
                        onClick = { viewModel.selectProduct(product) }
                    )
                }
            }
        }
    }
}

@Composable
fun MassiveGamingHeroBanner(
    language: AppLanguage,
    onExploreClick: () -> Unit,
    onAiSupportClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(340.dp)
            .background(Color(0xFF060709))
    ) {
        // High-Quality Character Art Visual
        Image(
            painter = painterResource(id = R.drawable.img_hero_banner),
            contentDescription = "Hero Cyber Warrior",
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp)),
            contentScale = ContentScale.Crop
        )

        // Dark Cyber Luxe Gradient Overlays
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0x4D060709),
                            Color(0x99060709),
                            Color(0xFF060709)
                        ),
                        startY = 0f,
                        endY = 1100f
                    )
                )
        )

        // Banner Content & Typography
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.Bottom
        ) {
            // Live Status Tag
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(CyberNeonGreen)
                )
                Text(
                    text = "RING-0 KERNEL ENGINE • 100% STEALTH",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp,
                        fontSize = 9.5.sp
                    ),
                    color = CyberNeonGreen
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Bold Headline "PLAY MORE. PAY LESS."
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "PLAY MORE. ",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = (-0.5).sp,
                        fontSize = 28.sp
                    ),
                    color = Color.White
                )
                Text(
                    text = "PAY LESS.",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = (-0.5).sp,
                        fontSize = 28.sp
                    ),
                    color = CyberAccentOrange
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Instant 1-Click Vault Delivery • HWID Spoofer • 10Gbps Stealth VPNs • Verified Game Keys",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                ),
                color = Color(0xCCFFFFFF),
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CyberButton(
                    text = "EXPLORE DEALS",
                    onClick = onExploreClick,
                    color = CyberAccentOrange,
                    textColor = Color(0xFF000000),
                    icon = { Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.weight(1.2f),
                    testTag = "hero_explore_button"
                )

                CyberOutlinedButton(
                    text = "AI ADVISOR",
                    onClick = onAiSupportClick,
                    borderColor = Color(0x4DFF6B00),
                    backgroundColor = Color(0x80101422),
                    textColor = Color.White,
                    icon = { Icon(Icons.Default.Psychology, contentDescription = null, tint = CyberAccentOrange, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.weight(1f),
                    testTag = "hero_ai_button"
                )
            }
        }
    }
}

@Composable
fun GamingFlashSaleSection(
    flashProducts: List<ProductEntity>,
    currency: AppCurrency,
    language: AppLanguage,
    onProductClick: (ProductEntity) -> Unit
) {
    CyberGlowingCard(
        modifier = Modifier.fillMaxWidth(),
        glowColor = CyberAccentOrange
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocalFireDepartment,
                        contentDescription = "Flash Deals",
                        tint = CyberAccentOrange,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "HOT FLASH DEALS",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            fontSize = 14.sp
                        ),
                        color = CyberAccentOrange
                    )
                }

                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .border(BorderStroke(1.dp, CyberAccentOrange.copy(alpha = 0.4f)), RoundedCornerShape(6.dp)),
                    color = CyberAccentOrange.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "⏱️ ENDS IN 03:42:19",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Black,
                            fontSize = 9.sp
                        ),
                        color = CyberAccentOrange,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                flashProducts.take(2).forEach { prod ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .border(BorderStroke(1.dp, Color(0xFF252D40)), RoundedCornerShape(12.dp))
                            .clickable { onProductClick(prod) },
                        color = Color(0xFF090B10)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF141926)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bolt,
                                        contentDescription = null,
                                        tint = CyberAccentOrange,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (language == AppLanguage.BANGLA) prod.titleBn else prod.title,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${prod.platform} • INSTANT DISPATCH",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                        color = CyberTextMuted
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "-65%",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Black,
                                            fontSize = 10.sp
                                        ),
                                        color = CyberNeonGreen
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = CurrencyFormatter.format(prod.basePriceUsd * 0.35, currency),
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Black,
                                            color = CyberAccentOrange
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GamingProductCard(
    product: ProductEntity,
    currency: AppCurrency,
    language: AppLanguage,
    onClick: () -> Unit
) {
    // Choose appropriate thumbnail image or icon
    val hasCustomArt = product.iconName == "game" || product.iconName == "shield"
    val artDrawableId = if (product.iconName == "game") R.drawable.img_game_tactical else R.drawable.img_cyber_shield

    CyberCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("product_card_${product.id}"),
        borderColor = if (product.isFeatured) CyberAccentOrange.copy(alpha = 0.6f) else Color(0xFF222838),
        backgroundColor = Color(0xD910131C),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Section: Thumbnail / Icon + Title + Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (hasCustomArt) {
                        Image(
                            painter = painterResource(id = artDrawableId),
                            contentDescription = product.title,
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(BorderStroke(1.dp, CyberAccentOrange.copy(alpha = 0.4f)), RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF161A26))
                                .border(BorderStroke(1.dp, Color(0xFF252D40)), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (product.iconName) {
                                    "vpn" -> Icons.Default.VpnLock
                                    "terminal" -> Icons.Default.Code
                                    "key" -> Icons.Default.Key
                                    else -> Icons.Default.Computer
                                },
                                contentDescription = product.title,
                                tint = CyberAccentOrange,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = if (language == AppLanguage.BANGLA) product.titleBn else product.title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                fontSize = 15.sp,
                                letterSpacing = 0.3.sp
                            ),
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = product.platform,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                ),
                                color = Color(0x99FFFFFF)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "•", color = Color(0x66FFFFFF))
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Rating",
                                tint = CyberAccentOrange,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "${product.rating} (${product.reviewCount})",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = Color(0xB3FFFFFF)
                            )
                        }
                    }
                }

                if (product.badge != null) {
                    CyberBadge(
                        text = product.badge,
                        color = when (product.badge) {
                            "BESTSELLER" -> CyberAccentOrange
                            "PRO CHOICE" -> CyberNeonPink
                            "HOT" -> CyberNeonOrange
                            "VERIFIED" -> CyberNeonGreen
                            else -> CyberAccentOrange
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Short Description
            Text(
                text = if (language == AppLanguage.BANGLA) product.shortDescBn else product.shortDesc,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                ),
                color = Color(0xB3FFFFFF),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Bottom Pricing & Duration Action
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "STARTING FROM",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        ),
                        color = Color(0x66FFFFFF)
                    )
                    Text(
                        text = CurrencyFormatter.format(product.basePriceUsd * 0.35, currency),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black,
                            color = CyberAccentOrange,
                            fontSize = 18.sp
                        )
                    )
                }

                CyberButton(
                    text = LocalizationEngine.get("select_duration", language),
                    onClick = onClick,
                    color = CyberAccentOrange,
                    textColor = Color(0xFF000000),
                    icon = { Icon(Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    testTag = "btn_select_plan_${product.id}"
                )
            }
        }
    }
}
