package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.repository.MarketRepository
import com.example.data.repository.OrderAndVaultRepository
import com.example.data.repository.SupportAndSecurityRepository
import com.example.data.repository.WalletAndUserRepository
import com.example.data.seed.InitialDataSeeder
import com.example.domain.engine.DoubleEntryLedgerEngine
import com.example.domain.engine.KeyAllocationEngine
import com.example.ui.components.CyberBottomNav
import com.example.ui.components.CyberTopBar
import com.example.ui.screens.admin.AdminDashboardScreen
import com.example.ui.screens.orders.OrdersScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.store.CheckoutDialog
import com.example.ui.screens.store.ProductDetailDialog
import com.example.ui.screens.store.StoreScreen
import com.example.ui.screens.support.SupportAiScreen
import com.example.ui.screens.wallet.WalletScreen
import com.example.ui.theme.CyberCanvas
import com.example.ui.theme.TEAMGHOSTTheme
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.MainViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val db = AppDatabase.getDatabase(applicationContext)
        val keyAllocationEngine = KeyAllocationEngine(db)
        val doubleEntryLedgerEngine = DoubleEntryLedgerEngine(db)

        val marketRepo = MarketRepository(db)
        val orderRepo = OrderAndVaultRepository(db, keyAllocationEngine, doubleEntryLedgerEngine)
        val walletRepo = WalletAndUserRepository(db, doubleEntryLedgerEngine)
        val supportRepo = SupportAndSecurityRepository(db)

        val viewModelFactory = MainViewModelFactory(marketRepo, orderRepo, walletRepo, supportRepo)

        setContent {
            TEAMGHOSTTheme {
                val viewModel: MainViewModel = viewModel(factory = viewModelFactory)

                // Initialize Database on App Startup
                LaunchedEffect(Unit) {
                    InitialDataSeeder.seedDatabase(db)
                }

                TeamGhostApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun TeamGhostApp(viewModel: MainViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState()
    val currency by viewModel.currency.collectAsState()
    val language by viewModel.language.collectAsState()

    val selectedProduct by viewModel.selectedProduct.collectAsState()
    val productDurationPlans by viewModel.productDurationPlans.collectAsState()
    val selectedDurationPlan by viewModel.selectedDurationPlan.collectAsState()
    val paymentMethods by viewModel.paymentMethods.collectAsState()
    val selectedPaymentMethod by viewModel.selectedPaymentMethod.collectAsState()
    val checkoutState by viewModel.checkoutState.collectAsState()
    val isCheckingOut by viewModel.isCheckingOut.collectAsState()
    val walletBalance by viewModel.walletBalance.collectAsState()

    val isSuperAdmin = currentUser?.role == "SUPER_ADMIN"

    Scaffold(
        topBar = {
            CyberTopBar(
                currentUser = currentUser,
                allUsers = allUsers,
                selectedCurrency = currency,
                selectedLanguage = language,
                onCurrencySelect = { viewModel.setCurrency(it) },
                onLanguageSelect = { viewModel.setLanguage(it) },
                onUserSelect = { viewModel.switchUser(it) },
                onAdminClick = {
                    if (isSuperAdmin) {
                        viewModel.setTab(AppNavTab.ADMIN)
                    }
                }
            )
        },
        bottomBar = {
            CyberBottomNav(
                currentTab = currentTab,
                onTabSelect = { viewModel.setTab(it) },
                isSuperAdmin = isSuperAdmin,
                language = language
            )
        },
        containerColor = CyberCanvas
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CyberCanvas)
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppNavTab.STORE -> StoreScreen(viewModel = viewModel)
                AppNavTab.ORDERS -> OrdersScreen(viewModel = viewModel)
                AppNavTab.WALLET -> WalletScreen(viewModel = viewModel)
                AppNavTab.SUPPORT -> SupportAiScreen(viewModel = viewModel)
                AppNavTab.PROFILE -> ProfileScreen(viewModel = viewModel)
                AppNavTab.ADMIN -> AdminDashboardScreen(viewModel = viewModel)
            }
        }
    }

    // Product Detail Sheet / Modal
    if (selectedProduct != null && selectedPaymentMethod == null && checkoutState == null) {
        ProductDetailDialog(
            product = selectedProduct!!,
            durationPlans = productDurationPlans,
            selectedPlan = selectedDurationPlan,
            currency = currency,
            language = language,
            onPlanSelect = { viewModel.selectDurationPlan(it) },
            onProceedToCheckout = {
                val defaultMethod = paymentMethods.firstOrNull { it.code == "WALLET" } ?: paymentMethods.firstOrNull()
                if (defaultMethod != null) {
                    viewModel.selectPaymentMethod(defaultMethod)
                }
            },
            onDismiss = { viewModel.selectProduct(null) }
        )
    }

    // Checkout Modal with instant key delivery
    if (selectedProduct != null && selectedDurationPlan != null && selectedPaymentMethod != null) {
        CheckoutDialog(
            product = selectedProduct!!,
            plan = selectedDurationPlan!!,
            paymentMethods = paymentMethods,
            selectedMethod = selectedPaymentMethod,
            checkoutResult = checkoutState,
            isCheckingOut = isCheckingOut,
            walletBalance = walletBalance,
            currency = currency,
            language = language,
            onSelectPaymentMethod = { viewModel.selectPaymentMethod(it) },
            onConfirmPayment = { txnId -> viewModel.executeCheckout(txnId) },
            onDismiss = {
                viewModel.selectProduct(null)
                viewModel.clearCheckoutState()
            }
        )
    }
}
