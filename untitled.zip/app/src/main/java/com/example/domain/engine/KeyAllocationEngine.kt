package com.example.domain.engine

import com.example.data.local.AppDatabase
import com.example.data.local.entity.DigitalKeyEntity
import com.example.data.local.entity.KeyStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed class KeyAllocationResult {
    data class Success(val allocatedKey: DigitalKeyEntity) : KeyAllocationResult()
    data class OutOfStock(val message: String) : KeyAllocationResult()
    data class Error(val reason: String) : KeyAllocationResult()
}

class KeyAllocationEngine(private val db: AppDatabase) {

    /**
     * Atomically reserves and assigns an AVAILABLE digital key to an order.
     * Uses optimistic lockVersion + status check to ensure no two concurrent purchases
     * can claim the same key.
     */
    suspend fun allocateKeyForOrder(
        productId: String,
        durationId: String,
        durationDays: Int,
        orderId: String,
        userId: String
    ): KeyAllocationResult = withContext(Dispatchers.IO) {
        val digitalKeyDao = db.digitalKeyDao()

        // 1. Check if key is already assigned to this order (idempotency check)
        val existingAssignedKey = digitalKeyDao.getKeyByOrderId(orderId)
        if (existingAssignedKey != null) {
            return@withContext KeyAllocationResult.Success(existingAssignedKey)
        }

        // 2. Find first candidate available key
        val candidate = digitalKeyDao.findFirstAvailableKey(productId, durationId)
            ?: return@withContext KeyAllocationResult.OutOfStock(
                "No digital license keys available in vault for this duration plan. Please contact admin or choose another plan."
            )

        val now = System.currentTimeMillis()
        val expiresAt = if (durationDays >= 9999) null else now + (durationDays.toLong() * 86400 * 1000)

        // 3. Perform atomic conditional update
        val updatedRows = digitalKeyDao.atomicAssignKey(
            keyId = candidate.id,
            expectedCurrentStatus = KeyStatus.AVAILABLE.name,
            status = KeyStatus.ASSIGNED.name,
            orderId = orderId,
            userId = userId,
            assignedAt = now,
            expiresAt = expiresAt
        )

        if (updatedRows > 0) {
            // Successfully claimed
            val updatedKey = digitalKeyDao.getKeyById(candidate.id)
            if (updatedKey != null) {
                return@withContext KeyAllocationResult.Success(updatedKey)
            }
        }

        // If another transaction claimed this exact key simultaneously, retry once
        val retryCandidate = digitalKeyDao.findFirstAvailableKey(productId, durationId)
            ?: return@withContext KeyAllocationResult.OutOfStock("Vault stock depleted during concurrent checkout.")

        val retryRows = digitalKeyDao.atomicAssignKey(
            keyId = retryCandidate.id,
            expectedCurrentStatus = KeyStatus.AVAILABLE.name,
            status = KeyStatus.ASSIGNED.name,
            orderId = orderId,
            userId = userId,
            assignedAt = now,
            expiresAt = expiresAt
        )

        if (retryRows > 0) {
            val updatedKey = digitalKeyDao.getKeyById(retryCandidate.id)
            if (updatedKey != null) {
                return@withContext KeyAllocationResult.Success(updatedKey)
            }
        }

        return@withContext KeyAllocationResult.Error("Key allocation failed due to high concurrency lock contention.")
    }
}
