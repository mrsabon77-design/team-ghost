package com.example.domain.model

enum class AppCurrency(
    val code: String,
    val symbol: String,
    val exchangeRateToUsd: Double // 1 USD in this currency
) {
    USD("USD", "$", 1.0),
    BDT("BDT", "৳", 122.50),
    EUR("EUR", "€", 0.92),
    USDT("USDT", "₮", 1.0)
}

enum class AppLanguage(val code: String, val displayName: String) {
    ENGLISH("en", "English"),
    BANGLA("bn", "বাংলা")
}

object CurrencyFormatter {
    fun format(amountUsd: Double, currency: AppCurrency): String {
        val converted = amountUsd * currency.exchangeRateToUsd
        return when (currency) {
            AppCurrency.USD -> "$${String.format("%.2f", converted)}"
            AppCurrency.BDT -> "৳${String.format("%.0f", converted)}"
            AppCurrency.EUR -> "€${String.format("%.2f", converted)}"
            AppCurrency.USDT -> "${String.format("%.2f", converted)} ₮"
        }
    }
}

object LocalizationEngine {
    private val enStrings = mapOf(
        "app_title" to "TEAM GHOST",
        "tagline" to "PREMIUM DIGITAL MARKETPLACE",
        "nav_store" to "STORE",
        "nav_orders" to "ORDERS",
        "nav_wallet" to "WALLET",
        "nav_support" to "AI SUPPORT",
        "nav_profile" to "PROFILE",
        "nav_admin" to "ADMIN VAULT",
        "search_placeholder" to "Search keys, bypasses, tools, software...",
        "featured" to "FEATURED DROPS",
        "flash_sale" to "FLASH SALE",
        "trending" to "TRENDING NOW",
        "all_products" to "PRODUCT CATALOG",
        "filter_all" to "All",
        "filter_gaming" to "Gaming",
        "filter_software" to "Software",
        "filter_vpn" to "VPN & Privacy",
        "filter_subs" to "Subscriptions",
        "filter_devtools" to "Dev Tools",
        "filter_security" to "Security",
        "select_duration" to "Select Duration Plan",
        "buy_now" to "INSTANT PURCHASE",
        "in_stock" to "Keys in Vault",
        "out_of_stock" to "Out of Stock",
        "instant_delivery" to "Instant 1-Click Vault Delivery",
        "wallet_balance" to "Wallet Ledger Balance",
        "top_up" to "Top Up Balance",
        "send" to "Transfer",
        "recent_transactions" to "Double-Entry Ledger Audit Trail",
        "orders_title" to "Your License Vault & Orders",
        "reveal_key" to "Reveal Plain Key",
        "key_copied" to "Key copied to clipboard!",
        "order_details" to "Order Receipt",
        "super_admin" to "Super Admin",
        "loyalty_tier" to "Loyalty Status",
        "referral_program" to "Referral Rewards",
        "security_center" to "Security & 2FA",
        "currency_selector" to "Currency",
        "language_selector" to "Language",
        "admin_dashboard" to "Team Ghost Master Control",
        "key_inventory" to "Digital Key Inventory",
        "reconciliation" to "Payment Reconciliation",
        "user_management" to "User RBAC & Privileges",
        "security_audit" to "Security Audit & Telemetry",
        "feature_flags" to "Feature Flags",
        "api_docs" to "API Explorer"
    )

    private val bnStrings = mapOf(
        "app_title" to "টিম ঘোস্ট",
        "tagline" to "প্রিমিয়াম ডিজিটাল মার্কেটপ্লেস",
        "nav_store" to "স্টোর",
        "nav_orders" to "অর্ডারসমূহ",
        "nav_wallet" to "ওয়ালেট",
        "nav_support" to "এআই সাপোর্ট",
        "nav_profile" to "প্রোফাইল",
        "nav_admin" to "অ্যাডমিন ভল্ট",
        "search_placeholder" to "ডিজিটাল কী, সফটওয়্যার, টুলস খুঁজুন...",
        "featured" to "ফিচার্ড প্রোডাক্ট",
        "flash_sale" to "ফ্ল্যাশ সেল",
        "trending" to "জনপ্রিয় পণ্য",
        "all_products" to "সকল প্রোডাক্ট",
        "filter_all" to "সব",
        "filter_gaming" to "গেমিং",
        "filter_software" to "সফটওয়্যার",
        "filter_vpn" to "ভিপিএন",
        "filter_subs" to "সাবস্ক্রিপশন",
        "filter_devtools" to "ডেভ টুলস",
        "filter_security" to "সিকিউরিটি",
        "select_duration" to "মেয়াদ নির্বাচন করুন",
        "buy_now" to "তাৎক্ষণিক ক্রয়",
        "in_stock" to "ভল্টে স্টকে আছে",
        "out_of_stock" to "স্টক শেষ",
        "instant_delivery" to "১-ক্লিক ভল্ট ডেলিভারি",
        "wallet_balance" to "ওয়ালেট লেজার ব্যালেন্স",
        "top_up" to "টপ আপ ব্যালেন্স",
        "send" to "ট্রান্সফার",
        "recent_transactions" to "ডাবল-এন্ট্রি লেজার ট্রানজেকশন",
        "orders_title" to "আপনার ডিজিটাল কী ও অর্ডার",
        "reveal_key" to "লাইসেন্স কী দেখুন",
        "key_copied" to "কী কপি করা হয়েছে!",
        "order_details" to "অর্ডার রশিদ",
        "super_admin" to "সুপার অ্যাডমিন",
        "loyalty_tier" to "লয়ালটি স্ট্যাটাস",
        "referral_program" to "রেফারেল রিওয়ার্ড",
        "security_center" to "নিরাপত্তা ও ২এফএ",
        "currency_selector" to "মুদ্রা / কারেন্সি",
        "language_selector" to "ভাষা",
        "admin_dashboard" to "টিম ঘোস্ট মাস্টার কন্ট্রোল",
        "key_inventory" to "ডিজিটাল কী ইনভেন্টরি",
        "reconciliation" to "পেমেন্ট রিকনসিলিয়েশন",
        "user_management" to "ইউজার রোল ও পারমিশন",
        "security_audit" to "সিকিউরিটি অডিট ও লগ",
        "feature_flags" to "ফিচার ফ্ল্যাগস",
        "api_docs" to "এপিআই ডকুমেন্টেশন"
    )

    fun get(key: String, language: AppLanguage): String {
        return if (language == AppLanguage.BANGLA) {
            bnStrings[key] ?: enStrings[key] ?: key
        } else {
            enStrings[key] ?: key
        }
    }
}
