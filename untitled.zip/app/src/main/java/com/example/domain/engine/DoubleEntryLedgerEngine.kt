package com.example.domain.engine

import com.example.data.local.AppDatabase
import com.example.data.local.entity.LedgerEntryType
import com.example.data.local.entity.LedgerTransactionCategory
import com.example.data.local.entity.WalletLedgerEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

sealed class LedgerResult {
    data class Success(val newBalanceUsd: Double, val ledgerEntry: WalletLedgerEntity) : LedgerResult()
    data class InsufficientFunds(val currentBalanceUsd: Double, val requiredUsd: Double) : LedgerResult()
    data class Error(val message: String) : LedgerResult()
}

class DoubleEntryLedgerEngine(private val db: AppDatabase) {

    /**
     * Credits funds to a user's wallet ledger (e.g. Top-up, refund, referral commission).
     */
    suspend fun credit(
        userId: String,
        amountUsd: Double,
        category: LedgerTransactionCategory,
        referenceId: String,
        description: String
    ): LedgerResult = withContext(Dispatchers.IO) {
        if (amountUsd <= 0.0) {
            return@withContext LedgerResult.Error("Credit amount must be greater than zero.")
        }

        val currentBalance = db.walletLedgerDao().getCalculatedBalanceDirect(userId)
        val newBalance = currentBalance + amountUsd

        val entry = WalletLedgerEntity(
            id = "ledger_${UUID.randomUUID()}",
            userId = userId,
            entryType = LedgerEntryType.CREDIT.name,
            category = category.name,
            amountUsd = amountUsd,
            balanceAfterUsd = newBalance,
            referenceId = referenceId,
            description = description,
            timestamp = System.currentTimeMillis()
        )

        db.walletLedgerDao().insertLedgerEntry(entry)
        LedgerResult.Success(newBalance, entry)
    }

    /**
     * Debits funds from a user's wallet ledger for a purchase.
     */
    suspend fun debit(
        userId: String,
        amountUsd: Double,
        category: LedgerTransactionCategory,
        referenceId: String,
        description: String
    ): LedgerResult = withContext(Dispatchers.IO) {
        if (amountUsd <= 0.0) {
            return@withContext LedgerResult.Error("Debit amount must be greater than zero.")
        }

        val currentBalance = db.walletLedgerDao().getCalculatedBalanceDirect(userId)
        if (currentBalance < amountUsd) {
            return@withContext LedgerResult.InsufficientFunds(currentBalance, amountUsd)
        }

        val newBalance = currentBalance - amountUsd

        val entry = WalletLedgerEntity(
            id = "ledger_${UUID.randomUUID()}",
            userId = userId,
            entryType = LedgerEntryType.DEBIT.name,
            category = category.name,
            amountUsd = amountUsd,
            balanceAfterUsd = newBalance,
            referenceId = referenceId,
            description = description,
            timestamp = System.currentTimeMillis()
        )

        db.walletLedgerDao().insertLedgerEntry(entry)
        LedgerResult.Success(newBalance, entry)
    }
}
