package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entity.FeatureFlagEntity
import com.example.data.local.entity.SecurityAuditLogEntity
import com.example.data.local.entity.SupportMessageEntity
import com.example.data.local.entity.SupportTicketEntity
import com.example.data.remote.GeminiApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

class SupportAndSecurityRepository(private val db: AppDatabase) {

    fun getTicketsForUser(userId: String): Flow<List<SupportTicketEntity>> =
        db.supportTicketDao().getTicketsByUserId(userId)

    fun getAllTickets(): Flow<List<SupportTicketEntity>> = db.supportTicketDao().getAllTickets()

    fun getMessagesForTicket(ticketId: String): Flow<List<SupportMessageEntity>> =
        db.supportMessageDao().getMessagesForTicket(ticketId)

    fun getRecentAuditLogs(): Flow<List<SecurityAuditLogEntity>> =
        db.securityAuditLogDao().getRecentAuditLogs()

    fun getHighRiskSecurityAlerts(): Flow<List<SecurityAuditLogEntity>> =
        db.securityAuditLogDao().getHighRiskSecurityAlerts()

    fun getFeatureFlags(): Flow<List<FeatureFlagEntity>> = db.featureFlagDao().getAllFlags()

    suspend fun toggleFeatureFlag(key: String, isEnabled: Boolean) {
        db.featureFlagDao().setFlag(key, isEnabled)
    }

    suspend fun createTicket(
        userId: String,
        userEmail: String,
        subject: String,
        category: String,
        initialMessage: String
    ): String = withContext(Dispatchers.IO) {
        val ticketId = "tick_${UUID.randomUUID().toString().take(8)}"
        val ticketNumber = "TG-TCK-${System.currentTimeMillis().toString().takeLast(4)}"

        val ticket = SupportTicketEntity(
            id = ticketId,
            ticketNumber = ticketNumber,
            userId = userId,
            userEmail = userEmail,
            subject = subject,
            category = category,
            status = "OPEN"
        )
        db.supportTicketDao().insertTicket(ticket)

        val userMsg = SupportMessageEntity(
            id = "msg_${UUID.randomUUID()}",
            ticketId = ticketId,
            senderType = "USER",
            senderName = userEmail.substringBefore("@"),
            message = initialMessage,
            timestamp = System.currentTimeMillis()
        )
        db.supportMessageDao().insertMessage(userMsg)

        // Automatically trigger AI Agent response to ticket
        val aiReply = GeminiApiClient.askGhostAi(
            userPrompt = "$subject: $initialMessage",
            contextInfo = "Category: $category. Ticket Number: $ticketNumber."
        )

        val botMsg = SupportMessageEntity(
            id = "msg_${UUID.randomUUID()}",
            ticketId = ticketId,
            senderType = "AI_BOT",
            senderName = "GHOST AI Tier-1 Agent",
            message = aiReply,
            timestamp = System.currentTimeMillis() + 500
        )
        db.supportMessageDao().insertMessage(botMsg)

        ticketId
    }

    suspend fun sendTicketMessage(
        ticketId: String,
        senderType: String,
        senderName: String,
        message: String
    ) = withContext(Dispatchers.IO) {
        val msg = SupportMessageEntity(
            id = "msg_${UUID.randomUUID()}",
            ticketId = ticketId,
            senderType = senderType,
            senderName = senderName,
            message = message,
            timestamp = System.currentTimeMillis()
        )
        db.supportMessageDao().insertMessage(msg)

        if (senderType == "USER") {
            val aiReply = GeminiApiClient.askGhostAi(
                userPrompt = message,
                contextInfo = "Ongoing Support Ticket ID: $ticketId"
            )
            val botMsg = SupportMessageEntity(
                id = "msg_${UUID.randomUUID()}",
                ticketId = ticketId,
                senderType = "AI_BOT",
                senderName = "GHOST AI Core",
                message = aiReply,
                timestamp = System.currentTimeMillis() + 600
            )
            db.supportMessageDao().insertMessage(botMsg)
        }
    }

    suspend fun askInstantAi(question: String): String = withContext(Dispatchers.IO) {
        GeminiApiClient.askGhostAi(question, "Instant AI Support Hub Chat")
    }

    suspend fun updateTicketStatus(ticketId: String, newStatus: String) {
        db.supportTicketDao().updateTicketStatus(ticketId, newStatus)
    }
}
