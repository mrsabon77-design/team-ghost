package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.WalletLedgerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WalletLedgerDao {
    @Query("SELECT * FROM wallet_ledger WHERE userId = :userId ORDER BY timestamp DESC")
    fun getLedgerByUserId(userId: String): Flow<List<WalletLedgerEntity>>

    @Query("SELECT * FROM wallet_ledger ORDER BY timestamp DESC")
    fun getAllLedgerEntries(): Flow<List<WalletLedgerEntity>>

    @Query("""
        SELECT COALESCE(
            (SELECT SUM(amountUsd) FROM wallet_ledger WHERE userId = :userId AND entryType = 'CREDIT'), 0.0
        ) - COALESCE(
            (SELECT SUM(amountUsd) FROM wallet_ledger WHERE userId = :userId AND entryType = 'DEBIT'), 0.0
        )
    """)
    fun getCalculatedBalance(userId: String): Flow<Double>

    @Query("""
        SELECT COALESCE(
            (SELECT SUM(amountUsd) FROM wallet_ledger WHERE userId = :userId AND entryType = 'CREDIT'), 0.0
        ) - COALESCE(
            (SELECT SUM(amountUsd) FROM wallet_ledger WHERE userId = :userId AND entryType = 'DEBIT'), 0.0
        )
    """)
    suspend fun getCalculatedBalanceDirect(userId: String): Double

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedgerEntry(entry: WalletLedgerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedgerEntries(entries: List<WalletLedgerEntity>)
}
