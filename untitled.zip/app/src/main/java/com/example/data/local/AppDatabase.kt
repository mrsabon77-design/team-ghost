package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.DigitalKeyDao
import com.example.data.local.dao.DurationPlanDao
import com.example.data.local.dao.FeatureFlagDao
import com.example.data.local.dao.NotificationDao
import com.example.data.local.dao.OrderDao
import com.example.data.local.dao.PaymentMethodDao
import com.example.data.local.dao.ProductDao
import com.example.data.local.dao.ReferralDao
import com.example.data.local.dao.SecurityAuditLogDao
import com.example.data.local.dao.SupportMessageDao
import com.example.data.local.dao.SupportTicketDao
import com.example.data.local.dao.UserDao
import com.example.data.local.dao.WalletLedgerDao
import com.example.data.local.entity.DigitalKeyEntity
import com.example.data.local.entity.DurationPlanEntity
import com.example.data.local.entity.FeatureFlagEntity
import com.example.data.local.entity.NotificationEntity
import com.example.data.local.entity.OrderEntity
import com.example.data.local.entity.PaymentMethodEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ReferralEntity
import com.example.data.local.entity.SecurityAuditLogEntity
import com.example.data.local.entity.SupportMessageEntity
import com.example.data.local.entity.SupportTicketEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.WalletLedgerEntity

@Database(
    entities = [
        UserEntity::class,
        ProductEntity::class,
        DurationPlanEntity::class,
        DigitalKeyEntity::class,
        OrderEntity::class,
        WalletLedgerEntity::class,
        PaymentMethodEntity::class,
        ReferralEntity::class,
        NotificationEntity::class,
        SupportTicketEntity::class,
        SupportMessageEntity::class,
        SecurityAuditLogEntity::class,
        FeatureFlagEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun productDao(): ProductDao
    abstract fun durationPlanDao(): DurationPlanDao
    abstract fun digitalKeyDao(): DigitalKeyDao
    abstract fun orderDao(): OrderDao
    abstract fun walletLedgerDao(): WalletLedgerDao
    abstract fun paymentMethodDao(): PaymentMethodDao
    abstract fun referralDao(): ReferralDao
    abstract fun notificationDao(): NotificationDao
    abstract fun supportTicketDao(): SupportTicketDao
    abstract fun supportMessageDao(): SupportMessageDao
    abstract fun securityAuditLogDao(): SecurityAuditLogDao
    abstract fun featureFlagDao(): FeatureFlagDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "team_ghost_v6_database.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
