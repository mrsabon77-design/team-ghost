package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.DigitalKeyEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DigitalKeyDao {
    @Query("SELECT * FROM digital_keys ORDER BY createdAt DESC")
    fun getAllKeys(): Flow<List<DigitalKeyEntity>>

    @Query("SELECT * FROM digital_keys WHERE productId = :productId AND durationId = :durationId AND status = 'AVAILABLE' LIMIT 1")
    suspend fun findFirstAvailableKey(productId: String, durationId: String): DigitalKeyEntity?

    @Query("SELECT COUNT(*) FROM digital_keys WHERE productId = :productId AND durationId = :durationId AND status = 'AVAILABLE'")
    fun getAvailableKeyCount(productId: String, durationId: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM digital_keys WHERE productId = :productId AND status = 'AVAILABLE'")
    fun getTotalAvailableCountForProduct(productId: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM digital_keys WHERE status = 'AVAILABLE'")
    fun getTotalAvailableVaultKeys(): Flow<Int>

    @Query("SELECT * FROM digital_keys WHERE orderId = :orderId LIMIT 1")
    suspend fun getKeyByOrderId(orderId: String): DigitalKeyEntity?

    @Query("SELECT * FROM digital_keys WHERE id = :keyId LIMIT 1")
    suspend fun getKeyById(keyId: String): DigitalKeyEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKeys(keys: List<DigitalKeyEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKey(key: DigitalKeyEntity)

    @Update
    suspend fun updateKey(key: DigitalKeyEntity)

    @Query("UPDATE digital_keys SET status = :status, orderId = :orderId, userId = :userId, assignedAt = :assignedAt, expiresAt = :expiresAt, lockVersion = lockVersion + 1 WHERE id = :keyId AND status = :expectedCurrentStatus")
    suspend fun atomicAssignKey(
        keyId: String,
        expectedCurrentStatus: String,
        status: String,
        orderId: String,
        userId: String,
        assignedAt: Long,
        expiresAt: Long?
    ): Int

    @Query("UPDATE digital_keys SET status = :status WHERE id = :keyId")
    suspend fun updateKeyStatus(keyId: String, status: String)
}
