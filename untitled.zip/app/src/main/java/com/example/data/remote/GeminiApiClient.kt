package com.example.data.remote

import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeminiPart(
    val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    val role: String? = "user",
    val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiRequest(
    val contents: List<GeminiContent>
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    val content: GeminiContent?
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    val candidates: List<GeminiCandidate>? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiApiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val apiService: GeminiApiService by lazy {
        retrofit.create(GeminiApiService::class.java)
    }

    suspend fun askGhostAi(userPrompt: String, contextInfo: String): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val systemPrompt = """
                    You are the official 24/7 AI Support Engineer for TEAM GHOST (Cyber Luxe Digital Marketplace & Key Vault).
                    TEAM GHOST provides genuine Ring-0 kernel drivers, HWID spoofers, gaming passes (Valorant Vanguard, CoD Warzone), Cybershield VPNs, AI workspaces, and Windows 11 digital licenses.
                    Context: $contextInfo
                    Answer concisely, professionally, with high-tech clarity and clear numbered setup steps where needed.
                """.trimIndent()

                val request = GeminiRequest(
                    contents = listOf(
                        GeminiContent(
                            role = "user",
                            parts = listOf(GeminiPart(text = "$systemPrompt\n\nUser Question: $userPrompt"))
                        )
                    )
                )

                val response = apiService.generateContent(apiKey = apiKey, request = request)
                val reply = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!reply.isNullOrBlank()) {
                    return@withContext reply.trim()
                }
            } catch (e: Exception) {
                // Fallback to local intelligent cyber support engine
            }
        }

        // Offline / Fallback Intelligent Cyber Knowledge Engine
        return@withContext generateLocalCyberResponse(userPrompt)
    }

    private fun generateLocalCyberResponse(prompt: String): String {
        val lower = prompt.lowercase()
        return when {
            "spoofer" in lower || "hwid" in lower || "ban" in lower -> {
                "🛡️ **GHOST HWID SPOOFER V6 Guide:**\n" +
                "1. Temporarily disable Anti-Virus & Windows Defender real-time protection.\n" +
                "2. Disable Secure Boot & TPM in BIOS (UEFI settings).\n" +
                "3. Run `GhostSpoofer_v6.exe` as Administrator.\n" +
                "4. Click **[AUTO CLEAN & SPOOF]** — all NIC MACs, GPU UUIDs & Disk serials are randomized in 3 seconds.\n" +
                "5. Launch your game with 100% clean serials!"
            }
            "key" in lower || "license" in lower || "where" in lower || "order" in lower -> {
                "🔑 **Digital Key Vault Access:**\n" +
                "Your purchased keys are instantly available in the **ORDERS** tab.\n" +
                "Tap **[Reveal Plain Key]** on your order receipt to view and copy your license key. Keys are cryptographically sealed in our vault until revealed."
            }
            "payment" in lower || "bkash" in lower || "nagad" in lower || "crypto" in lower || "usdt" in lower -> {
                "💳 **Payment Verification Protocol:**\n" +
                "• **bKash / Nagad / Rocket:** Send Money to the merchant number shown at checkout, then enter your TrxID for instant automated key assignment.\n" +
                "• **USDT (TRC-20 / BEP-20):** Send to our vault address. Key is released on 1 blockchain confirmation.\n" +
                "• **Internal Wallet:** Instant 0-second delivery with zero network fees!"
            }
            "vanguard" in lower || "valorant" in lower || "driver" in lower -> {
                "⚡ **VALORANT Vanguard Bypass Protocol:**\n" +
                "• Ensure Windows version is 21H2 - 23H2 or Windows 11.\n" +
                "• Hyper-V / Core Isolation must be turned OFF.\n" +
                "• Load the driver BEFORE launching the Riot Client.\n" +
                "• Use the in-game stream-proof overlay (Insert key)."
            }
            "wallet" in lower || "top up" in lower || "balance" in lower -> {
                "💰 **Wallet & Double-Entry Ledger:**\n" +
                "You can Top Up your wallet using bKash, Nagad, USDT, or Bitcoin. All credits and debits are strictly logged in your immutable transaction audit trail."
            }
            "refund" in lower || "issue" in lower || "not working" in lower -> {
                "📝 **Team Ghost Guarantee & Ticket Escalation:**\n" +
                "If a key fails to activate, our system will automatically verify the key state. If invalid, an instant wallet credit refund is processed within 15 minutes. Tap **[Open Support Ticket]** to connect with a senior technician."
            }
            else -> {
                "🤖 **TEAM GHOST AI Core:**\n" +
                "I've analyzed your query regarding: \"$prompt\".\n\n" +
                "• All digital products in our catalog feature instant automated key delivery from our Key Vault.\n" +
                "• For order troubleshooting or specific product guides, feel free to ask about HWID Spoofing, Vanguard/Ricochet bypasses, payment methods, or license activation!"
            }
        }
    }
}
