package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "payment_methods")
data class PaymentMethodEntity(
    @PrimaryKey val code: String, // WALLET, BKASH, NAGAD, ROCKET, UPAY, USDT_TRC20, USDT_BEP20, BTC, ETH, SOL
    val name: String,
    val nameBn: String,
    val category: String, // LOCAL, CRYPTO, WALLET
    val iconName: String, // wallet, bkash, nagad, rocket, crypto, btc, eth, sol
    val addressOrNumber: String,
    val instructions: String,
    val instructionsBn: String,
    val qrCodePayload: String,
    val network: String? = null,
    val feePercent: Double = 0.0,
    val isEnabled: Boolean = true
)
