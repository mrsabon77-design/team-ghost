package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class LedgerEntryType {
    CREDIT, // Adds money to user's wallet
    DEBIT   // Deducts money from user's wallet
}

enum class LedgerTransactionCategory {
    TOPUP,
    PURCHASE,
    REFUND,
    REFERRAL_BONUS,
    LOYALTY_REWARD,
    ADMIN_ADJUSTMENT
}

@Entity(
    tableName = "wallet_ledger",
    indices = [
        Index("userId"),
        Index("timestamp")
    ]
)
data class WalletLedgerEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val entryType: String, // CREDIT or DEBIT
    val category: String, // TOPUP, PURCHASE, REFUND, etc.
    val amountUsd: Double,
    val balanceAfterUsd: Double,
    val referenceId: String, // orderId or paymentTxnId or adminNote
    val description: String,
    val timestamp: Long = System.currentTimeMillis()
)
