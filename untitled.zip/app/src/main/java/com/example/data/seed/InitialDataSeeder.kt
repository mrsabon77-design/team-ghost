package com.example.data.seed

import com.example.data.local.AppDatabase
import com.example.data.local.entity.DigitalKeyEntity
import com.example.data.local.entity.DurationPlanEntity
import com.example.data.local.entity.FeatureFlagEntity
import com.example.data.local.entity.KeyStatus
import com.example.data.local.entity.LedgerEntryType
import com.example.data.local.entity.LedgerTransactionCategory
import com.example.data.local.entity.LoyaltyTier
import com.example.data.local.entity.NotificationEntity
import com.example.data.local.entity.PaymentMethodEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SecurityAuditLogEntity
import com.example.data.local.entity.SupportMessageEntity
import com.example.data.local.entity.SupportTicketEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.UserRole
import com.example.data.local.entity.WalletLedgerEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

object InitialDataSeeder {

    suspend fun seedDatabase(db: AppDatabase) = withContext(Dispatchers.IO) {
        val existingSuperAdmin = db.userDao().getUserByEmail("mrsabon77@gmail.com")
        if (existingSuperAdmin != null) {
            // Already seeded
            return@withContext
        }

        // 1. Seed Users (Super Admin & Demo User)
        val superAdmin = UserEntity(
            id = "user_super_admin_sabon",
            email = "mrsabon77@gmail.com",
            name = "Sabon (Super Admin)",
            role = UserRole.SUPER_ADMIN.name,
            loyaltyTier = LoyaltyTier.ELITE.name,
            loyaltyPoints = 5400,
            referralCode = "GHOST-ELITE-77",
            referredBy = null,
            isVerified = true,
            twoFactorEnabled = true,
            twoFactorSecret = "GHOST77SUPERSECRETKEY",
            avatarColorHex = "#00F0FF"
        )

        val demoUser = UserEntity(
            id = "user_demo_ghost",
            email = "operator@teamghost.io",
            name = "Ghost Hunter",
            role = UserRole.MEMBER.name,
            loyaltyTier = LoyaltyTier.GOLD.name,
            loyaltyPoints = 850,
            referralCode = "GHOST-HUNTER-99",
            referredBy = "GHOST-ELITE-77",
            isVerified = true,
            twoFactorEnabled = false,
            avatarColorHex = "#00FF88"
        )

        db.userDao().insertUsers(listOf(superAdmin, demoUser))

        // 2. Seed Products
        val products = listOf(
            ProductEntity(
                id = "prod_hwid_spoofer",
                title = "GHOST HWID SPOOFER V6",
                titleBn = "ঘোস্ট এইচডব্লিউআইডি স্পুফার ভি৬",
                category = "SECURITY",
                platform = "Windows 10/11",
                shortDesc = "Kernel Ring-0 Hardware Serial Cleaner, TPM & SecureBoot Bypass",
                shortDescBn = "কার্নেল রিং-০ হার্ডওয়্যার সিরিয়াল ক্লিনার এবং টিপিএম বাইপাস",
                fullDesc = "Enterprise-grade hardware ID spoofing engine. Randomizes NIC MAC, Disk Serials, Motherboard UUID, GPU UUID, and Monitor EDID instantly with zero trace. 100% Undetected with EAC, BattlEye, Vanguard & Ricochet.",
                iconName = "shield",
                themeColorHex = "#00F0FF",
                badge = "BESTSELLER",
                basePriceUsd = 14.99,
                rating = 4.98f,
                reviewCount = 542,
                isVerified = true,
                isFeatured = true,
                isTrending = true,
                isFlashSale = true,
                flashSaleEndsAt = System.currentTimeMillis() + (12 * 3600 * 1000)
            ),
            ProductEntity(
                id = "prod_val_vanguard",
                title = "VALORANT VANGUARD ECLIPSE",
                titleBn = "ভ্যালোরেন্ট ভ্যানগার্ড এক্লিপ্স",
                category = "GAMING",
                platform = "PC / Riot Client",
                shortDesc = "External Driver ESP, Silent Target Snap & Stream-Proof Overlay",
                shortDescBn = "এক্সটার্নাল ড্রাইভার ইএসপি, সাইলেন্ট টার্গেট স্ন্যাপ এবং স্ট্রিম-প্রুফ ওভারলে",
                fullDesc = "Undetected Ring-0 hypervisor hook. Features 2D Box ESP, Bone Skeleton, Spike Timer, Head Dot, Visibility Check, Recoil Smoothing and OBS Stream Bypass. Clean unhook on exit.",
                iconName = "game",
                themeColorHex = "#FF007F",
                badge = "PRO CHOICE",
                basePriceUsd = 19.99,
                rating = 4.95f,
                reviewCount = 389,
                isVerified = true,
                isFeatured = true,
                isTrending = true,
                isFlashSale = false
            ),
            ProductEntity(
                id = "prod_cod_warzone",
                title = "WARZONE RICOCHET GHOST PROTOCOL",
                titleBn = "ওয়ারজোন রিকোশেট ঘোস্ট প্রটোকল",
                category = "GAMING",
                platform = "PC / Battle.net & Steam",
                shortDesc = "Silent Aim, 2D Radar, Loot ESP & Velocity Prediction",
                shortDescBn = "সাইলেন্ট এইম, ২ডি রাডার, লুট ইএসপি এবং ভেলোসিটি প্রেডিকশন",
                fullDesc = "Built for Call of Duty Warzone & Modern Warfare III. Real-time bullet drop calculation, humanized smoothing, weapon sway removal and full distance/health radar.",
                iconName = "game",
                themeColorHex = "#FF9F1C",
                badge = "HOT",
                basePriceUsd = 12.99,
                rating = 4.91f,
                reviewCount = 274,
                isVerified = true,
                isFeatured = false,
                isTrending = true,
                isFlashSale = true,
                flashSaleEndsAt = System.currentTimeMillis() + (8 * 3600 * 1000)
            ),
            ProductEntity(
                id = "prod_cybershield_vpn",
                title = "CYBERSHIELD ULTRA VPN 10GBPS",
                titleBn = "সাইবারশিল্ড আল্ট্রা ভিপিএন ১০জিবিপিএস",
                category = "VPN",
                platform = "Cross-Platform",
                shortDesc = "WireGuard Stealth Tunnel, Dedicated Residential IPs & Zero Logs",
                shortDescBn = "ওয়্যারগার্ড স্টেলথ টানেল, ডেডিকেটেড আইপি এবং জিরো লগ",
                fullDesc = "Military-grade ChaCha20 encryption with automated kill switch, multi-hop obfuscation, DNS leak prevention, and 85+ global offshore locations.",
                iconName = "vpn",
                themeColorHex = "#00FF88",
                badge = "VERIFIED",
                basePriceUsd = 4.99,
                rating = 4.99f,
                reviewCount = 612,
                isVerified = true,
                isFeatured = true,
                isTrending = false,
                isFlashSale = false
            ),
            ProductEntity(
                id = "prod_discord_nitro",
                title = "DISCORD NITRO BOOST (1 YEAR)",
                titleBn = "ডিসকর্ড নাইট্রো বুস্ট (১ বছর)",
                category = "SUBSCRIPTIONS",
                platform = "All Devices",
                shortDesc = "Direct Account Upgrade with 2 Server Boosts, HD Stream & Custom Emojis",
                shortDescBn = "২টি সার্ভার বুস্ট, এইচডি স্ট্রিম ও কাস্টম ইমোজি সহ সরাসরি একাউন্ট আপগ্রেড",
                fullDesc = "Instant digital gift link with zero risk. Works on existing and new accounts globally. Includes 500MB upload limit, animated avatar/banner and custom badge.",
                iconName = "play",
                themeColorHex = "#9D4EDD",
                badge = "INSTANT",
                basePriceUsd = 29.99,
                rating = 4.97f,
                reviewCount = 890,
                isVerified = true,
                isFeatured = true,
                isTrending = true,
                isFlashSale = false
            ),
            ProductEntity(
                id = "prod_ai_enterprise",
                title = "CHATGPT 4o & CLAUDE 3.7 PRO WORKSPACE",
                titleBn = "চ্যাটজিপিটি এবং ক্লদ প্রো ওয়ার্কস্পেস",
                category = "DEV_TOOLS",
                platform = "Web / Mobile / API",
                shortDesc = "Unlimited Thinking Tokens, DALL-E 3 & Code Execution Engine",
                shortDescBn = "আনলিমিটেড থিংকিং টোকেন, ডাল-ই ৩ ও কোড এক্সিকিউশন ইঞ্জিন",
                fullDesc = "Dedicated high-speed enterprise seat with maximum context window (200k tokens), instant reasoning, Canvas artifact editor and fast generation speeds.",
                iconName = "terminal",
                themeColorHex = "#00F0FF",
                badge = "TOP AI",
                basePriceUsd = 18.99,
                rating = 4.96f,
                reviewCount = 430,
                isVerified = true,
                isFeatured = false,
                isTrending = true,
                isFlashSale = false
            ),
            ProductEntity(
                id = "prod_win11_pro",
                title = "WINDOWS 11 PRO RETAIL OEM KEY",
                titleBn = "উইন্ডোজ ১১ প্রো রিটেইল লাইসেন্স কী",
                category = "SOFTWARE",
                platform = "PC / Windows",
                shortDesc = "Lifetime Genuine Digital Activation Key with Microsoft Support",
                shortDescBn = "মাইক্রোসফট সাপোর্ট সহ লাইফটাইম জেনুইন ডিজিটাল অ্যাক্টিভেশন কী",
                fullDesc = "Official Microsoft Retail License bindable to your Microsoft account. Supports 32-bit & 64-bit with all language packs, BitLocker encryption, Remote Desktop and Hyper-V.",
                iconName = "key",
                themeColorHex = "#38BDF8",
                badge = "LIFETIME",
                basePriceUsd = 11.99,
                rating = 4.99f,
                reviewCount = 1120,
                isVerified = true,
                isFeatured = false,
                isTrending = false,
                isFlashSale = false
            )
        )
        db.productDao().insertProducts(products)

        // 3. Seed Duration Plans for Each Product
        val durationPlans = mutableListOf<DurationPlanEntity>()
        products.forEach { prod ->
            val plans = listOf(
                DurationPlanEntity(
                    id = "plan_${prod.id}_1d",
                    productId = prod.id,
                    durationLabel = "1 Day Trial",
                    durationLabelBn = "১ দিন ট্রায়াল",
                    durationDays = 1,
                    multiplier = 0.35,
                    discountPercent = 0,
                    isPopular = false
                ),
                DurationPlanEntity(
                    id = "plan_${prod.id}_3d",
                    productId = prod.id,
                    durationLabel = "3 Days Access",
                    durationLabelBn = "৩ দিন অ্যাক্সেস",
                    durationDays = 3,
                    multiplier = 0.65,
                    discountPercent = 5,
                    isPopular = false
                ),
                DurationPlanEntity(
                    id = "plan_${prod.id}_7d",
                    productId = prod.id,
                    durationLabel = "7 Days Pass",
                    durationLabelBn = "৭ দিন পাস",
                    durationDays = 7,
                    multiplier = 1.0,
                    discountPercent = 10,
                    isPopular = true
                ),
                DurationPlanEntity(
                    id = "plan_${prod.id}_30d",
                    productId = prod.id,
                    durationLabel = "30 Days Monthly",
                    durationLabelBn = "৩০ দিন মাসিক",
                    durationDays = 30,
                    multiplier = 2.4,
                    discountPercent = 20,
                    isPopular = false
                ),
                DurationPlanEntity(
                    id = "plan_${prod.id}_lifetime",
                    productId = prod.id,
                    durationLabel = "Lifetime VIP Access",
                    durationLabelBn = "লাইফটাইম ভিআইপি অ্যাক্সেস",
                    durationDays = 9999,
                    multiplier = 5.5,
                    discountPercent = 35,
                    isPopular = false
                )
            )
            durationPlans.addAll(plans)
        }
        db.durationPlanDao().insertPlans(durationPlans)

        // 4. Seed Enterprise Digital Key Vault
        val digitalKeys = mutableListOf<DigitalKeyEntity>()
        durationPlans.forEach { plan ->
            // Create 3 available keys for each duration plan so stock is always ready
            for (i in 1..3) {
                val rawKey = "TG-${plan.productId.takeLast(4).uppercase()}-${plan.durationDays}D-${UUID.randomUUID().toString().take(8).uppercase()}"
                val maskedKey = "TG-****-****-${rawKey.takeLast(4)}"
                digitalKeys.add(
                    DigitalKeyEntity(
                        id = "key_${plan.id}_stock_$i",
                        productId = plan.productId,
                        durationId = plan.id,
                        encryptedKey = maskedKey,
                        plainKey = rawKey,
                        status = KeyStatus.AVAILABLE.name,
                        orderId = null,
                        userId = null,
                        createdAt = System.currentTimeMillis()
                    )
                )
            }
        }
        db.digitalKeyDao().insertKeys(digitalKeys)

        // 5. Seed Payment Methods
        val paymentMethods = listOf(
            PaymentMethodEntity(
                code = "WALLET",
                name = "Team Ghost Internal Wallet",
                nameBn = "টিম ঘোস্ট ইন্টারনাল ওয়ালেট",
                category = "WALLET",
                iconName = "wallet",
                addressOrNumber = "Direct Ledger Balance",
                instructions = "Pay instantly with zero network fees from your encrypted wallet balance.",
                instructionsBn = "আপনার ওয়ালেট ব্যালেন্স থেকে জিরো ফিতে তাৎক্ষণিক পেমেন্ট সম্পন্ন করুন।",
                qrCodePayload = "TG-WALLET-DIRECT-PAY",
                feePercent = 0.0,
                isEnabled = true
            ),
            PaymentMethodEntity(
                code = "BKASH",
                name = "bKash Merchant / Personal",
                nameBn = "বিকাশ মার্চেন্ট / পার্সোনাল",
                category = "LOCAL",
                iconName = "bkash",
                addressOrNumber = "01788-990077 (Send Money)",
                instructions = "Send Money to 01788-990077. Enter your Transaction ID (TrxID) below for instant automated confirmation.",
                instructionsBn = "01788-990077 নাম্বারে Send Money করুন। ট্রানজেকশন আইডি (TrxID) নিচে প্রদান করুন।",
                qrCodePayload = "01788990077",
                feePercent = 0.0,
                isEnabled = true
            ),
            PaymentMethodEntity(
                code = "NAGAD",
                name = "Nagad Direct Pay",
                nameBn = "নগদ ডিরেক্ট পে",
                category = "LOCAL",
                iconName = "nagad",
                addressOrNumber = "01855-667788 (Send Money)",
                instructions = "Send exact amount to Nagad number 01855-667788. Provide Nagad Txn ID.",
                instructionsBn = "নগদ নাম্বারে 01855-667788 সেন্ড মানি করে ট্রানজেকশন আইডি লিখুন।",
                qrCodePayload = "01855667788",
                feePercent = 0.0,
                isEnabled = true
            ),
            PaymentMethodEntity(
                code = "ROCKET",
                name = "Rocket / DBBL Pay",
                nameBn = "রকেট / ডাচ-বাংলা",
                category = "LOCAL",
                iconName = "rocket",
                addressOrNumber = "01933-221100-9 (Send Money)",
                instructions = "Transfer via Rocket to 01933-221100-9 and enter TrxID.",
                instructionsBn = "রকেট নাম্বারে 01933-221100-9 সেন্ড মানি করুন।",
                qrCodePayload = "019332211009",
                feePercent = 0.0,
                isEnabled = true
            ),
            PaymentMethodEntity(
                code = "USDT_TRC20",
                name = "USDT (TRC-20 Tron Network)",
                nameBn = "ইউএসডিটি (টিআরসি-২০ ট্রন)",
                category = "CRYPTO",
                iconName = "crypto",
                addressOrNumber = "TGhost77EnterpriseVaultAddressTrc20Xk99",
                instructions = "Send USDT (TRC-20) to the address below. Instant blockchain verification in 1 block.",
                instructionsBn = "নিচের টিআরসি-২০ এড্রেসে ইউএসডিটি পাঠান। ১টি ব্লক কনফার্মেশনে কী রিলিজ হবে।",
                qrCodePayload = "TGhost77EnterpriseVaultAddressTrc20Xk99",
                network = "TRON (TRC-20)",
                feePercent = 0.0,
                isEnabled = true
            ),
            PaymentMethodEntity(
                code = "USDT_BEP20",
                name = "USDT (BEP-20 BSC Network)",
                nameBn = "ইউএসডিটি (বিইপি-২০ বিএনবি চেইন)",
                category = "CRYPTO",
                iconName = "crypto",
                addressOrNumber = "0xGhost77VaultCryptoBscChainContract88",
                instructions = "Send USDT on BNB Smart Chain (BEP-20). Enter transaction hash.",
                instructionsBn = "বিএনবি চেইনে ইউএসডিটি পাঠান ও হ্যাশ দিন।",
                qrCodePayload = "0xGhost77VaultCryptoBscChainContract88",
                network = "BNB Smart Chain (BEP-20)",
                feePercent = 0.0,
                isEnabled = true
            ),
            PaymentMethodEntity(
                code = "BTC",
                name = "Bitcoin (BTC Native SegWit)",
                nameBn = "বিটকয়েন (বিটিসি)",
                category = "CRYPTO",
                iconName = "btc",
                addressOrNumber = "bc1qghostcyberluxevaultbtc999777",
                instructions = "Send exact BTC to the SegWit address.",
                instructionsBn = "নিচের বিটকয়েন এড্রেসে সেন্ড করুন।",
                qrCodePayload = "bc1qghostcyberluxevaultbtc999777",
                network = "Bitcoin Mainnet",
                feePercent = 0.0,
                isEnabled = true
            ),
            PaymentMethodEntity(
                code = "SOL",
                name = "Solana (SOL Direct Pay)",
                nameBn = "সোলানা (এসওএল)",
                category = "CRYPTO",
                iconName = "sol",
                addressOrNumber = "GhostSolanaCyberLuxeFastPayAddress8899",
                instructions = "Fast sub-second transfer on Solana network.",
                instructionsBn = "সোলানা নেটওয়ার্কে দ্রুত ট্রান্সফার করুন।",
                qrCodePayload = "GhostSolanaCyberLuxeFastPayAddress8899",
                network = "Solana",
                feePercent = 0.0,
                isEnabled = true
            )
        )
        db.paymentMethodDao().insertPaymentMethods(paymentMethods)

        // 6. Seed Double-Entry Wallet Ledger for initial balances
        val ledgerEntries = listOf(
            WalletLedgerEntity(
                id = "ledger_init_admin_1",
                userId = superAdmin.id,
                entryType = LedgerEntryType.CREDIT.name,
                category = LedgerTransactionCategory.TOPUP.name,
                amountUsd = 250.00,
                balanceAfterUsd = 250.00,
                referenceId = "TXN-ADMIN-INIT-01",
                description = "Initial Super Admin Seed Balance",
                timestamp = System.currentTimeMillis() - (86400 * 1000 * 2)
            ),
            WalletLedgerEntity(
                id = "ledger_init_user_1",
                userId = demoUser.id,
                entryType = LedgerEntryType.CREDIT.name,
                category = LedgerTransactionCategory.TOPUP.name,
                amountUsd = 50.00,
                balanceAfterUsd = 50.00,
                referenceId = "TXN-USER-INIT-01",
                description = "Initial Ghost Hunter Account Credit",
                timestamp = System.currentTimeMillis() - (86400 * 1000)
            )
        )
        db.walletLedgerDao().insertLedgerEntries(ledgerEntries)

        // 7. Seed Initial Notifications & Security Logs
        val notifications = listOf(
            NotificationEntity(
                id = "notif_welcome_admin",
                userId = superAdmin.id,
                title = "Welcome to TEAM GHOST V6 Master Control",
                message = "Super Admin privileges activated for mrsabon77@gmail.com. Key Vault & Double-entry ledger online.",
                category = "SYSTEM",
                channel = "IN_APP",
                isRead = false
            ),
            NotificationEntity(
                id = "notif_welcome_user",
                userId = demoUser.id,
                title = "VIP Membership Active",
                message = "Welcome to TEAM GHOST! You have $50.00 wallet credit and Gold tier status.",
                category = "PROMOTION",
                channel = "IN_APP",
                isRead = false
            )
        )
        notifications.forEach { db.notificationDao().insertNotification(it) }

        // 8. Seed Feature Flags
        val flags = listOf(
            FeatureFlagEntity(
                key = "flash_sales",
                label = "Flash Sales & Countdown Timer",
                isEnabled = true,
                description = "Enables limited-time discounted drops on home screen"
            ),
            FeatureFlagEntity(
                key = "ai_customer_support",
                label = "24/7 AI Support Agent (Gemini)",
                isEnabled = true,
                description = "Instant troubleshooting, key activation assistance and ticket routing"
            ),
            FeatureFlagEntity(
                key = "telegram_notifications",
                label = "Telegram Bot Order Dispatcher",
                isEnabled = true,
                description = "Simulates instant Telegram order receipts and key delivery alerts"
            ),
            FeatureFlagEntity(
                key = "crypto_gateways",
                label = "Crypto Payment Gateways (USDT/BTC/SOL)",
                isEnabled = true,
                description = "Enable decentralized cryptocurrency payments"
            ),
            FeatureFlagEntity(
                key = "local_bdt_gateways",
                label = "Local Payment Gateways (bKash/Nagad/Rocket)",
                isEnabled = true,
                description = "Enable Bangladeshi Taka instant payment verification"
            ),
            FeatureFlagEntity(
                key = "multi_vendor_beta",
                label = "Multi-Vendor Marketplace Submissions",
                isEnabled = false,
                description = "Allows third-party verified sellers to list license keys"
            )
        )
        db.featureFlagDao().insertFlags(flags)

        // 9. Seed Security Audit Log
        val auditLog = SecurityAuditLogEntity(
            id = "audit_init_boot",
            userId = superAdmin.id,
            action = "SYSTEM_INITIALIZE",
            category = "AUTH",
            ipAddress = "127.0.0.1",
            riskScore = "LOW",
            status = "SUCCESS",
            details = "TEAM GHOST V6 Enterprise Engine initialized with zero-trust RBAC and encrypted Key Vault."
        )
        db.securityAuditLogDao().insertLog(auditLog)

        // 10. Seed Initial Support Ticket
        val sampleTicket = SupportTicketEntity(
            id = "ticket_init_01",
            ticketNumber = "TG-TICK-1001",
            userId = demoUser.id,
            userEmail = demoUser.email,
            subject = "HWID Spoofer BIOS TPM Setup Guide",
            category = "TECH_SUPPORT",
            priority = "MEDIUM",
            status = "RESOLVED",
            createdAt = System.currentTimeMillis() - 3600000,
            updatedAt = System.currentTimeMillis() - 1800000
        )
        db.supportTicketDao().insertTicket(sampleTicket)

        db.supportMessageDao().insertMessage(
            SupportMessageEntity(
                id = "msg_01",
                ticketId = sampleTicket.id,
                senderType = "USER",
                senderName = "Ghost Hunter",
                message = "How do I disable Secure Boot before running the Kernel Spoofer?",
                timestamp = System.currentTimeMillis() - 3600000
            )
        )
        db.supportMessageDao().insertMessage(
            SupportMessageEntity(
                id = "msg_02",
                ticketId = sampleTicket.id,
                senderType = "AI_BOT",
                senderName = "GHOST AI Core",
                message = "To disable Secure Boot:\n1. Restart PC and enter BIOS (Del / F2 / F12)\n2. Navigate to 'Security' or 'Boot' tab\n3. Set 'Secure Boot' to Disabled\n4. Save & Exit (F10).\nThe Spoofer driver will then load cleanly at Ring-0.",
                timestamp = System.currentTimeMillis() - 3400000
            )
        )
    }
}
