package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entity.DigitalKeyEntity
import com.example.data.local.entity.LedgerTransactionCategory
import com.example.data.local.entity.NotificationEntity
import com.example.data.local.entity.OrderEntity
import com.example.data.local.entity.OrderStatus
import com.example.data.local.entity.PaymentMethodEntity
import com.example.data.local.entity.SecurityAuditLogEntity
import com.example.domain.engine.DoubleEntryLedgerEngine
import com.example.domain.engine.KeyAllocationEngine
import com.example.domain.engine.KeyAllocationResult
import com.example.domain.engine.LedgerResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

sealed class CheckoutResult {
    data class Success(val order: OrderEntity, val assignedKey: String) : CheckoutResult()
    data class PaymentPendingVerification(val order: OrderEntity, val message: String) : CheckoutResult()
    data class InsufficientWalletBalance(val requiredUsd: Double, val currentBalanceUsd: Double) : CheckoutResult()
    data class OutOfStock(val message: String) : CheckoutResult()
    data class Failed(val error: String) : CheckoutResult()
}

class OrderAndVaultRepository(
    private val db: AppDatabase,
    private val keyAllocationEngine: KeyAllocationEngine,
    private val doubleEntryLedgerEngine: DoubleEntryLedgerEngine
) {

    fun getOrdersForUser(userId: String): Flow<List<OrderEntity>> = db.orderDao().getOrdersByUserId(userId)

    fun getAllOrders(): Flow<List<OrderEntity>> = db.orderDao().getAllOrders()

    fun getActivePaymentMethods(): Flow<List<PaymentMethodEntity>> = db.paymentMethodDao().getActivePaymentMethods()

    fun getAllPaymentMethods(): Flow<List<PaymentMethodEntity>> = db.paymentMethodDao().getAllPaymentMethods()

    fun getAllKeys(): Flow<List<DigitalKeyEntity>> = db.digitalKeyDao().getAllKeys()

    fun getTotalVaultKeysCount(): Flow<Int> = db.digitalKeyDao().getTotalAvailableVaultKeys()

    fun getTotalRevenue(): Flow<Double?> = db.orderDao().getTotalRevenue()

    fun getCompletedOrdersCount(): Flow<Int> = db.orderDao().getCompletedOrdersCount()

    suspend fun processCheckout(
        userId: String,
        userEmail: String,
        productId: String,
        productTitle: String,
        durationId: String,
        durationLabel: String,
        durationDays: Int,
        amountUsd: Double,
        currencyCode: String,
        localAmount: Double,
        paymentMethodCode: String,
        paymentTxnId: String?,
        idempotencyKey: String
    ): CheckoutResult = withContext(Dispatchers.IO) {
        val orderDao = db.orderDao()

        // 1. Check idempotency: If order with this idempotency key already completed, return existing order
        val existingOrder = orderDao.getOrderByIdempotencyKey(idempotencyKey)
        if (existingOrder != null && existingOrder.status == OrderStatus.COMPLETED.name) {
            return@withContext CheckoutResult.Success(existingOrder, existingOrder.assignedKey ?: "KEY-RESTORED")
        }

        val orderId = existingOrder?.id ?: "ord_${UUID.randomUUID().toString().take(12)}"
        val orderNumber = existingOrder?.orderNumber ?: "TG-${System.currentTimeMillis().toString().takeLast(6)}"

        // 2. If paying via Internal Wallet Balance
        if (paymentMethodCode == "WALLET") {
            // Debit from double-entry ledger
            val ledgerRes = doubleEntryLedgerEngine.debit(
                userId = userId,
                amountUsd = amountUsd,
                category = LedgerTransactionCategory.PURCHASE,
                referenceId = orderId,
                description = "Purchase: $productTitle ($durationLabel)"
            )

            when (ledgerRes) {
                is LedgerResult.InsufficientFunds -> {
                    return@withContext CheckoutResult.InsufficientWalletBalance(
                        requiredUsd = ledgerRes.requiredUsd,
                        currentBalanceUsd = ledgerRes.currentBalanceUsd
                    )
                }
                is LedgerResult.Error -> {
                    return@withContext CheckoutResult.Failed(ledgerRes.message)
                }
                is LedgerResult.Success -> {
                    // Wallet debited successfully, proceed to atomic key allocation
                }
            }
        }

        // 3. Perform Atomic Key Allocation
        val allocRes = keyAllocationEngine.allocateKeyForOrder(
            productId = productId,
            durationId = durationId,
            durationDays = durationDays,
            orderId = orderId,
            userId = userId
        )

        when (allocRes) {
            is KeyAllocationResult.OutOfStock -> {
                // If wallet was debited, automatically refund
                if (paymentMethodCode == "WALLET") {
                    doubleEntryLedgerEngine.credit(
                        userId = userId,
                        amountUsd = amountUsd,
                        category = LedgerTransactionCategory.REFUND,
                        referenceId = orderId,
                        description = "Automated Refund: Out of stock for $productTitle"
                    )
                }
                return@withContext CheckoutResult.OutOfStock(allocRes.message)
            }
            is KeyAllocationResult.Error -> {
                if (paymentMethodCode == "WALLET") {
                    doubleEntryLedgerEngine.credit(
                        userId = userId,
                        amountUsd = amountUsd,
                        category = LedgerTransactionCategory.REFUND,
                        referenceId = orderId,
                        description = "Automated Refund: Allocation failed for $productTitle"
                    )
                }
                return@withContext CheckoutResult.Failed(allocRes.reason)
            }
            is KeyAllocationResult.Success -> {
                val assignedKey = allocRes.allocatedKey
                val now = System.currentTimeMillis()

                val completedOrder = OrderEntity(
                    id = orderId,
                    orderNumber = orderNumber,
                    userId = userId,
                    userEmail = userEmail,
                    productId = productId,
                    productTitle = productTitle,
                    durationId = durationId,
                    durationLabel = durationLabel,
                    status = OrderStatus.COMPLETED.name,
                    currency = currencyCode,
                    amountUsd = amountUsd,
                    localAmount = localAmount,
                    paymentMethodCode = paymentMethodCode,
                    paymentTxnId = paymentTxnId ?: "WAL-TXN-${UUID.randomUUID().toString().take(8).uppercase()}",
                    idempotencyKey = idempotencyKey,
                    assignedKey = assignedKey.plainKey,
                    keyExpiresAt = assignedKey.expiresAt,
                    createdAt = now,
                    completedAt = now
                )

                orderDao.insertOrder(completedOrder)

                // Award loyalty points (10 points per $1)
                val pointsEarned = (amountUsd * 10).toInt().coerceAtLeast(10)
                db.userDao().addLoyaltyPoints(userId, pointsEarned)

                // Dispatch in-app notification & simulate Telegram webhook
                db.notificationDao().insertNotification(
                    NotificationEntity(
                        id = "notif_${UUID.randomUUID()}",
                        userId = userId,
                        title = "Order #$orderNumber Completed",
                        message = "Your license key for $productTitle ($durationLabel) has been delivered to your vault.",
                        category = "ORDER",
                        channel = "IN_APP"
                    )
                )

                // Security Audit Log
                db.securityAuditLogDao().insertLog(
                    SecurityAuditLogEntity(
                        id = "audit_${UUID.randomUUID()}",
                        userId = userId,
                        action = "KEY_DELIVERY_COMPLETE",
                        category = "VAULT",
                        riskScore = "LOW",
                        status = "SUCCESS",
                        details = "Order #$orderNumber fulfilled. Key ${assignedKey.id} assigned to user $userEmail."
                    )
                )

                return@withContext CheckoutResult.Success(completedOrder, assignedKey.plainKey)
            }
        }
    }

    suspend fun addKeysInBulk(
        productId: String,
        durationId: String,
        rawKeys: List<String>
    ): Int = withContext(Dispatchers.IO) {
        val keysToAdd = rawKeys.filter { it.isNotBlank() }.map { plain ->
            val masked = if (plain.length > 8) "TG-****-${plain.takeLast(4)}" else "TG-****-KEY"
            DigitalKeyEntity(
                id = "key_${UUID.randomUUID()}",
                productId = productId,
                durationId = durationId,
                encryptedKey = masked,
                plainKey = plain.trim(),
                status = "AVAILABLE",
                orderId = null,
                userId = null,
                createdAt = System.currentTimeMillis()
            )
        }
        db.digitalKeyDao().insertKeys(keysToAdd)
        keysToAdd.size
    }

    suspend fun updateKeyStatus(keyId: String, status: String) {
        db.digitalKeyDao().updateKeyStatus(keyId, status)
    }
}
