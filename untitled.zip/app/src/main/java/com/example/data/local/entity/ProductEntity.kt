package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val title: String,
    val titleBn: String,
    val category: String, // GAMING, SOFTWARE, VPN, STREAMING, DEV_TOOLS, SECURITY
    val platform: String, // PC / Windows, Android, iOS, Steam, Cross-Platform
    val shortDesc: String,
    val shortDescBn: String,
    val fullDesc: String,
    val iconName: String, // shield, game, key, vpn, terminal, play
    val themeColorHex: String,
    val badge: String? = null,
    val basePriceUsd: Double,
    val rating: Float = 4.9f,
    val reviewCount: Int = 128,
    val isVerified: Boolean = true,
    val isFeatured: Boolean = false,
    val isTrending: Boolean = false,
    val isFlashSale: Boolean = false,
    val flashSaleEndsAt: Long = 0L,
    val status: String = "ACTIVE" // ACTIVE, MAINTENANCE, HIDDEN
)
