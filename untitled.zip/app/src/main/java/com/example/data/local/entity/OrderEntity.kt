package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class OrderStatus {
    CREATED,
    PAYMENT_PENDING,
    PAYMENT_VERIFYING,
    PAYMENT_VERIFIED,
    KEY_RESERVED,
    KEY_ASSIGNED,
    COMPLETED,
    PAYMENT_FAILED,
    PAYMENT_REJECTED,
    OUT_OF_STOCK,
    CANCELLED,
    REFUNDED
}

@Entity(
    tableName = "orders",
    indices = [
        Index("userId"),
        Index("status"),
        Index("idempotencyKey", unique = true),
        Index("orderNumber", unique = true)
    ]
)
data class OrderEntity(
    @PrimaryKey val id: String,
    val orderNumber: String, // e.g. TG-2026-8941
    val userId: String,
    val userEmail: String,
    val productId: String,
    val productTitle: String,
    val durationId: String,
    val durationLabel: String,
    val status: String = OrderStatus.CREATED.name,
    val currency: String = "USD",
    val amountUsd: Double,
    val localAmount: Double,
    val paymentMethodCode: String,
    val paymentTxnId: String? = null,
    val idempotencyKey: String,
    val assignedKey: String? = null,
    val keyExpiresAt: Long? = null,
    val failureReason: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)
