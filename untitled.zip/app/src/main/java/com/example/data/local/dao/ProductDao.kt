package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.DurationPlanEntity
import com.example.data.local.entity.ProductEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE status != 'HIDDEN' ORDER BY isFeatured DESC, isTrending DESC, rating DESC")
    fun getAllProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE id = :productId LIMIT 1")
    fun getProductById(productId: String): Flow<ProductEntity?>

    @Query("SELECT * FROM products WHERE category = :category AND status != 'HIDDEN'")
    fun getProductsByCategory(category: String): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE isFlashSale = 1 AND status != 'HIDDEN'")
    fun getFlashSaleProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE title LIKE '%' || :query || '%' OR shortDesc LIKE '%' || :query || '%'")
    fun searchProducts(query: String): Flow<List<ProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity)

    @Update
    suspend fun updateProduct(product: ProductEntity)
}

@Dao
interface DurationPlanDao {
    @Query("SELECT * FROM duration_plans WHERE productId = :productId AND status = 'ACTIVE' ORDER BY durationDays ASC")
    fun getPlansForProduct(productId: String): Flow<List<DurationPlanEntity>>

    @Query("SELECT * FROM duration_plans WHERE id = :planId LIMIT 1")
    suspend fun getPlanById(planId: String): DurationPlanEntity?

    @Query("SELECT * FROM duration_plans")
    fun getAllPlans(): Flow<List<DurationPlanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlans(plans: List<DurationPlanEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlan(plan: DurationPlanEntity)

    @Update
    suspend fun updatePlan(plan: DurationPlanEntity)
}
