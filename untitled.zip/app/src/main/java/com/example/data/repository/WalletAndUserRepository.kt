package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entity.LedgerTransactionCategory
import com.example.data.local.entity.LoyaltyTier
import com.example.data.local.entity.NotificationEntity
import com.example.data.local.entity.ReferralEntity
import com.example.data.local.entity.SecurityAuditLogEntity
import com.example.data.local.entity.UserEntity
import com.example.data.local.entity.WalletLedgerEntity
import com.example.domain.engine.DoubleEntryLedgerEngine
import com.example.domain.engine.LedgerResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

class WalletAndUserRepository(
    private val db: AppDatabase,
    private val doubleEntryLedgerEngine: DoubleEntryLedgerEngine
) {

    fun getUser(userId: String): Flow<UserEntity?> = db.userDao().getUserById(userId)

    fun getAllUsers(): Flow<List<UserEntity>> = db.userDao().getAllUsers()

    fun getWalletBalance(userId: String): Flow<Double> = db.walletLedgerDao().getCalculatedBalance(userId)

    fun getLedgerHistory(userId: String): Flow<List<WalletLedgerEntity>> =
        db.walletLedgerDao().getLedgerByUserId(userId)

    fun getAllLedgerEntries(): Flow<List<WalletLedgerEntity>> = db.walletLedgerDao().getAllLedgerEntries()

    fun getReferrals(userId: String): Flow<List<ReferralEntity>> = db.referralDao().getReferralsByReferrer(userId)

    fun getReferralCount(userId: String): Flow<Int> = db.referralDao().getReferralCount(userId)

    fun getTotalBonusEarned(userId: String): Flow<Double> = db.referralDao().getTotalBonusEarned(userId)

    fun getNotifications(userId: String): Flow<List<NotificationEntity>> =
        db.notificationDao().getNotificationsByUserId(userId)

    fun getUnreadNotificationCount(userId: String): Flow<Int> =
        db.notificationDao().getUnreadCount(userId)

    suspend fun topUpWallet(
        userId: String,
        amountUsd: Double,
        paymentMethodCode: String,
        paymentTxnId: String
    ): LedgerResult = withContext(Dispatchers.IO) {
        val res = doubleEntryLedgerEngine.credit(
            userId = userId,
            amountUsd = amountUsd,
            category = LedgerTransactionCategory.TOPUP,
            referenceId = paymentTxnId,
            description = "Wallet Top-up via $paymentMethodCode"
        )

        if (res is LedgerResult.Success) {
            db.notificationDao().insertNotification(
                NotificationEntity(
                    id = "notif_${UUID.randomUUID()}",
                    userId = userId,
                    title = "Wallet Top-up Successful",
                    message = "$$amountUsd credited to your account via $paymentMethodCode.",
                    category = "PAYMENT"
                )
            )

            db.securityAuditLogDao().insertLog(
                SecurityAuditLogEntity(
                    id = "audit_${UUID.randomUUID()}",
                    userId = userId,
                    action = "WALLET_TOPUP",
                    category = "TRANSACTION",
                    riskScore = "LOW",
                    status = "SUCCESS",
                    details = "Wallet credited with $$amountUsd. TxnId: $paymentTxnId."
                )
            )
        }
        res
    }

    suspend fun redeemVoucher(userId: String, voucherCode: String): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val code = voucherCode.trim().uppercase()
        val bonus = when (code) {
            "GHOST2026" -> 10.0
            "CYBERLUXE" -> 25.0
            "ELITE77" -> 50.0
            "FREELICENSE" -> 5.0
            else -> null
        }

        if (bonus == null) {
            return@withContext false to "Invalid or expired voucher code."
        }

        doubleEntryLedgerEngine.credit(
            userId = userId,
            amountUsd = bonus,
            category = LedgerTransactionCategory.LOYALTY_REWARD,
            referenceId = "VOUCHER-$code",
            description = "Promo Code Reward: $code"
        )

        db.notificationDao().insertNotification(
            NotificationEntity(
                id = "notif_${UUID.randomUUID()}",
                userId = userId,
                title = "Voucher Redeemed!",
                message = "You received $$bonus wallet credit from voucher $code.",
                category = "PROMOTION"
            )
        )

        true to "Successfully redeemed $$bonus into your wallet balance!"
    }

    suspend fun updateUserRole(userId: String, newRole: String) {
        db.userDao().updateUserRole(userId, newRole)
        db.securityAuditLogDao().insertLog(
            SecurityAuditLogEntity(
                id = "audit_${UUID.randomUUID()}",
                userId = userId,
                action = "ROLE_MODIFIED",
                category = "ADMIN",
                riskScore = "HIGH",
                status = "SUCCESS",
                details = "User role changed to $newRole."
            )
        )
    }

    suspend fun setTwoFactor(userId: String, enabled: Boolean) {
        db.userDao().updateTwoFactor(userId, enabled)
    }

    suspend fun markNotificationsRead(userId: String) {
        db.notificationDao().markAllAsRead(userId)
    }
}
