package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    fun getUserById(userId: String): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users ORDER BY createdAt DESC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsers(users: List<UserEntity>)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET role = :newRole WHERE id = :userId")
    suspend fun updateUserRole(userId: String, newRole: String)

    @Query("UPDATE users SET loyaltyPoints = loyaltyPoints + :points WHERE id = :userId")
    suspend fun addLoyaltyPoints(userId: String, points: Int)

    @Query("UPDATE users SET loyaltyTier = :newTier WHERE id = :userId")
    suspend fun updateLoyaltyTier(userId: String, newTier: String)

    @Query("UPDATE users SET twoFactorEnabled = :enabled WHERE id = :userId")
    suspend fun updateTwoFactor(userId: String, enabled: Boolean)
}
