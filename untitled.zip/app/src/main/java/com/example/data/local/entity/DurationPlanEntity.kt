package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "duration_plans",
    foreignKeys = [
        ForeignKey(
            entity = ProductEntity::class,
            parentColumns = ["id"],
            childColumns = ["productId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("productId")]
)
data class DurationPlanEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val durationLabel: String, // 1 Day, 3 Days, 7 Days, 30 Days, 1 Year, Lifetime
    val durationLabelBn: String,
    val durationDays: Int,
    val multiplier: Double,
    val overridePriceUsd: Double? = null,
    val discountPercent: Int = 0,
    val isPopular: Boolean = false,
    val status: String = "ACTIVE"
) {
    fun calculateFinalPrice(basePrice: Double): Double {
        return overridePriceUsd ?: (basePrice * multiplier * (1.0 - discountPercent / 100.0))
    }
}
