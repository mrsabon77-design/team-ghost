package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class KeyStatus {
    AVAILABLE,
    RESERVED,
    ASSIGNED,
    USED,
    LOCKED,
    REVOKED
}

@Entity(
    tableName = "digital_keys",
    foreignKeys = [
        ForeignKey(
            entity = ProductEntity::class,
            parentColumns = ["id"],
            childColumns = ["productId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("productId"),
        Index("durationId"),
        Index("status"),
        Index("orderId")
    ]
)
data class DigitalKeyEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val durationId: String,
    val encryptedKey: String, // Stored encrypted / masked format e.g. GHOST-V6-XXXX-YYYY-ZZZZ
    val plainKey: String, // Key delivered to buyer upon order completion
    val status: String = KeyStatus.AVAILABLE.name,
    val orderId: String? = null,
    val userId: String? = null,
    val lockVersion: Long = 1L,
    val createdAt: Long = System.currentTimeMillis(),
    val assignedAt: Long? = null,
    val expiresAt: Long? = null
)
