package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "notifications",
    indices = [
        Index("userId"),
        Index("createdAt")
    ]
)
data class NotificationEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val title: String,
    val message: String,
    val category: String, // ORDER, PAYMENT, SECURITY, PROMOTION, REFERRAL, SYSTEM
    val channel: String = "IN_APP", // IN_APP, TELEGRAM, EMAIL
    val isRead: Boolean = false,
    val telegramDelivered: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
