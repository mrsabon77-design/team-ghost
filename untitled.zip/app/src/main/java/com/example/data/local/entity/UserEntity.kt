package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole {
    SUPER_ADMIN,
    ADMIN,
    MANAGER,
    SUPPORT,
    MEMBER
}

enum class LoyaltyTier {
    MEMBER,
    SILVER,
    GOLD,
    VIP,
    ELITE
}

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val email: String,
    val name: String,
    val role: String = UserRole.MEMBER.name,
    val loyaltyTier: String = LoyaltyTier.MEMBER.name,
    val loyaltyPoints: Int = 100,
    val referralCode: String,
    val referredBy: String? = null,
    val isVerified: Boolean = true,
    val twoFactorEnabled: Boolean = false,
    val twoFactorSecret: String = "GHOST-AUTH-KEY-88",
    val avatarColorHex: String = "#00F0FF",
    val createdAt: Long = System.currentTimeMillis()
)
