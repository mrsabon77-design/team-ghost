package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.FeatureFlagEntity
import com.example.data.local.entity.SecurityAuditLogEntity
import com.example.data.local.entity.SupportMessageEntity
import com.example.data.local.entity.SupportTicketEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SupportTicketDao {
    @Query("SELECT * FROM support_tickets WHERE userId = :userId ORDER BY updatedAt DESC")
    fun getTicketsByUserId(userId: String): Flow<List<SupportTicketEntity>>

    @Query("SELECT * FROM support_tickets ORDER BY updatedAt DESC")
    fun getAllTickets(): Flow<List<SupportTicketEntity>>

    @Query("SELECT * FROM support_tickets WHERE id = :ticketId LIMIT 1")
    fun getTicketById(ticketId: String): Flow<SupportTicketEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: SupportTicketEntity)

    @Update
    suspend fun updateTicket(ticket: SupportTicketEntity)

    @Query("UPDATE support_tickets SET status = :status, updatedAt = :updatedAt WHERE id = :ticketId")
    suspend fun updateTicketStatus(ticketId: String, status: String, updatedAt: Long = System.currentTimeMillis())
}

@Dao
interface SupportMessageDao {
    @Query("SELECT * FROM support_messages WHERE ticketId = :ticketId ORDER BY timestamp ASC")
    fun getMessagesForTicket(ticketId: String): Flow<List<SupportMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: SupportMessageEntity)
}

@Dao
interface SecurityAuditLogDao {
    @Query("SELECT * FROM security_audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentAuditLogs(): Flow<List<SecurityAuditLogEntity>>

    @Query("SELECT * FROM security_audit_logs WHERE userId = :userId ORDER BY timestamp DESC")
    fun getAuditLogsForUser(userId: String): Flow<List<SecurityAuditLogEntity>>

    @Query("SELECT * FROM security_audit_logs WHERE riskScore IN ('HIGH', 'CRITICAL') ORDER BY timestamp DESC")
    fun getHighRiskSecurityAlerts(): Flow<List<SecurityAuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: SecurityAuditLogEntity)
}

@Dao
interface FeatureFlagDao {
    @Query("SELECT * FROM feature_flags")
    fun getAllFlags(): Flow<List<FeatureFlagEntity>>

    @Query("SELECT isEnabled FROM feature_flags WHERE `key` = :key LIMIT 1")
    suspend fun isFlagEnabled(key: String): Boolean?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlags(flags: List<FeatureFlagEntity>)

    @Query("UPDATE feature_flags SET isEnabled = :isEnabled WHERE `key` = :key")
    suspend fun setFlag(key: String, isEnabled: Boolean)
}
