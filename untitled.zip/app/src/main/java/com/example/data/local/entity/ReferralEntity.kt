package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "referrals",
    indices = [
        Index("referrerUserId"),
        Index("referredUserId", unique = true)
    ]
)
data class ReferralEntity(
    @PrimaryKey val id: String,
    val referrerUserId: String,
    val referredUserId: String,
    val referredEmail: String,
    val bonusEarnedUsd: Double = 2.50,
    val status: String = "ACTIVE",
    val createdAt: Long = System.currentTimeMillis()
)
