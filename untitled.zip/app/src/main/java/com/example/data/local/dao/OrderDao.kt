package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.OrderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders WHERE userId = :userId ORDER BY createdAt DESC")
    fun getOrdersByUserId(userId: String): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE id = :orderId LIMIT 1")
    fun getOrderById(orderId: String): Flow<OrderEntity?>

    @Query("SELECT * FROM orders WHERE id = :orderId LIMIT 1")
    suspend fun getOrderByIdDirect(orderId: String): OrderEntity?

    @Query("SELECT * FROM orders WHERE idempotencyKey = :idempotencyKey LIMIT 1")
    suspend fun getOrderByIdempotencyKey(idempotencyKey: String): OrderEntity?

    @Query("SELECT * FROM orders WHERE status = :status ORDER BY createdAt DESC")
    fun getOrdersByStatus(status: String): Flow<List<OrderEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertOrder(order: OrderEntity)

    @Update
    suspend fun updateOrder(order: OrderEntity)

    @Query("UPDATE orders SET status = :status, assignedKey = :assignedKey, keyExpiresAt = :expiresAt, completedAt = :completedAt WHERE id = :orderId")
    suspend fun completeOrderWithKey(
        orderId: String,
        status: String,
        assignedKey: String,
        expiresAt: Long?,
        completedAt: Long
    )

    @Query("UPDATE orders SET status = :status, failureReason = :reason WHERE id = :orderId")
    suspend fun failOrder(orderId: String, status: String, reason: String)

    @Query("SELECT SUM(amountUsd) FROM orders WHERE status = 'COMPLETED'")
    fun getTotalRevenue(): Flow<Double?>

    @Query("SELECT COUNT(*) FROM orders WHERE status = 'COMPLETED'")
    fun getCompletedOrdersCount(): Flow<Int>
}
