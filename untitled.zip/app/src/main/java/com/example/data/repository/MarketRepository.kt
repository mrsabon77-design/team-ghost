package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entity.DurationPlanEntity
import com.example.data.local.entity.ProductEntity
import kotlinx.coroutines.flow.Flow

class MarketRepository(private val db: AppDatabase) {

    fun getAllProducts(): Flow<List<ProductEntity>> = db.productDao().getAllProducts()

    fun getProductById(productId: String): Flow<ProductEntity?> = db.productDao().getProductById(productId)

    fun getProductsByCategory(category: String): Flow<List<ProductEntity>> {
        return if (category == "ALL") {
            db.productDao().getAllProducts()
        } else {
            db.productDao().getProductsByCategory(category)
        }
    }

    fun getFlashSaleProducts(): Flow<List<ProductEntity>> = db.productDao().getFlashSaleProducts()

    fun searchProducts(query: String): Flow<List<ProductEntity>> = db.productDao().searchProducts(query)

    fun getDurationPlansForProduct(productId: String): Flow<List<DurationPlanEntity>> =
        db.durationPlanDao().getPlansForProduct(productId)

    fun getAvailableKeyCount(productId: String, durationId: String): Flow<Int> =
        db.digitalKeyDao().getAvailableKeyCount(productId, durationId)

    fun getTotalStockForProduct(productId: String): Flow<Int> =
        db.digitalKeyDao().getTotalAvailableCountForProduct(productId)

    suspend fun saveProduct(product: ProductEntity) = db.productDao().insertProduct(product)

    suspend fun saveDurationPlan(plan: DurationPlanEntity) = db.durationPlanDao().insertPlan(plan)
}
