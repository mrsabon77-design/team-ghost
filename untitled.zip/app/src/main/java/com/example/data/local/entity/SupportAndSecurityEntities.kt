package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "support_tickets",
    indices = [
        Index("userId"),
        Index("status")
    ]
)
data class SupportTicketEntity(
    @PrimaryKey val id: String,
    val ticketNumber: String,
    val userId: String,
    val userEmail: String,
    val subject: String,
    val category: String, // KEY_ISSUE, PAYMENT_STATUS, REFUND, TECH_SUPPORT, GENERAL
    val priority: String = "MEDIUM", // LOW, MEDIUM, HIGH, CRITICAL
    val status: String = "OPEN", // OPEN, IN_PROGRESS, RESOLVED, ESCALATED
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "support_messages",
    indices = [
        Index("ticketId"),
        Index("timestamp")
    ]
)
data class SupportMessageEntity(
    @PrimaryKey val id: String,
    val ticketId: String,
    val senderType: String, // USER, AI_BOT, AGENT
    val senderName: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "security_audit_logs",
    indices = [
        Index("userId"),
        Index("timestamp"),
        Index("riskScore")
    ]
)
data class SecurityAuditLogEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val action: String, // LOGIN, 2FA_VERIFY, CHECKOUT, KEY_ALLOCATION, ROLE_CHANGE, REFUND_REQUEST, ADMIN_OVERRIDE
    val category: String, // AUTH, TRANSACTION, VAULT, ADMIN, FRAUD_ALERT
    val ipAddress: String = "192.168.1.1",
    val riskScore: String = "LOW", // LOW, MEDIUM, HIGH, CRITICAL
    val status: String = "SUCCESS", // SUCCESS, BLOCKED, FLAG_REVIEW, FAILED
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "feature_flags")
data class FeatureFlagEntity(
    @PrimaryKey val key: String,
    val label: String,
    val isEnabled: Boolean,
    val description: String
)
